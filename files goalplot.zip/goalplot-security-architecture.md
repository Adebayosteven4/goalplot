# GoalPlot — Backend Security Architecture

A production-ready security blueprint for launching GoalPlot safely.

---

## 1. Authentication & Session Management

**Password Security**
- Hash all passwords with bcrypt (minimum 12 salt rounds)
- Enforce minimum 8 characters with uppercase, number, and symbol requirements
- Implement password breach checking against HaveIBeenPwned API
- Never store plain-text passwords anywhere — not in logs, not in emails, not in error messages

**Session Handling**
- Use JWTs (JSON Web Tokens) with short expiry (15 minutes for access tokens)
- Issue refresh tokens (7-day expiry) stored in HTTP-only, Secure, SameSite=Strict cookies
- Rotate refresh tokens on every use (one-time use tokens)
- Invalidate all sessions on password change

**Two-Factor Authentication (2FA)**
- Offer TOTP-based 2FA (Google Authenticator, Authy)
- Store backup recovery codes (hashed, single-use)
- Require 2FA for all VIP/paid accounts and admin access

---

## 2. API Security

**Rate Limiting**
- Login endpoint: 5 attempts per 15 minutes per IP, then progressive lockout
- Registration: 3 accounts per IP per hour
- Prediction submissions: 30 per minute per user
- Use Redis for rate limit counters (fast, atomic)

**Input Validation & Sanitization**
- Validate ALL inputs server-side (never trust the frontend alone)
- Use parameterized queries / prepared statements — zero raw SQL string concatenation
- Sanitize all user-generated content with a library like DOMPurify before storage
- Set maximum payload sizes (e.g., 1MB) to prevent abuse

**CSRF Protection**
- Generate unique CSRF tokens per session, tied to the user
- Validate tokens on every state-changing request (POST, PUT, DELETE)
- Use the SameSite cookie attribute as an additional layer

**CORS Configuration**
- Whitelist only your exact domain(s) — no wildcard origins
- Restrict allowed methods and headers

---

## 3. Database Security

**Encryption**
- Encrypt the database at rest (AES-256)
- Use TLS 1.3 for all database connections
- Encrypt sensitive fields (email, payment tokens) at the application level before storage

**Access Control**
- Use separate database users for read-only and read-write operations
- Apply principle of least privilege — the web app user should NOT have DROP or ALTER permissions
- Store database credentials in environment variables or a secrets manager (AWS Secrets Manager, Vault), never in code

**Prediction Integrity**
- Make predictions immutable once the match window closes
- Hash each prediction with a timestamp and user ID to create a tamper-proof record
- Store prediction hashes on-chain (optional) for provable fairness
- Log all prediction changes with full audit trail

---

## 4. Payment Security

**PCI-DSS Compliance**
- NEVER handle raw card numbers — use Stripe Elements, Paystack inline, or Flutterwave modal
- These providers are PCI-DSS Level 1 certified and handle card data on their servers
- Store only tokenized payment references, never card details
- Use webhooks (not client-side callbacks) to confirm payment status

**Webhook Verification**
- Verify webhook signatures from every payment provider
- Stripe: verify using stripe-signature header
- Paystack: verify using x-paystack-signature header
- Reject any webhook that fails signature validation
- Process webhooks idempotently (same event processed twice should not double-charge)

**Fraud Prevention**
- Flag duplicate payments from the same user within a short window
- Monitor for unusual patterns (rapid upgrades/downgrades, multiple cards per account)
- Implement refund limits and manual review for high-value transactions

---

## 5. Infrastructure & Network

**DDoS Protection**
- Put Cloudflare (or AWS CloudFront + WAF) in front of everything
- Enable rate limiting at the CDN/WAF level as the first line of defense
- Use Cloudflare's bot management to block automated attacks

**HTTPS Everything**
- TLS 1.3 minimum — disable TLS 1.0 and 1.1 entirely
- Enable HSTS (HTTP Strict Transport Security) with a long max-age
- Use certificate pinning for mobile apps if applicable

**HTTP Security Headers**
- Content-Security-Policy: restrict script sources, prevent inline scripts
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY (prevent clickjacking)
- Referrer-Policy: strict-origin-when-cross-origin
- Permissions-Policy: disable camera, microphone, geolocation unless needed

**Server Hardening**
- Run the application as a non-root user
- Disable directory listing
- Remove server version headers (don't reveal "nginx 1.x" or "Express")
- Keep all dependencies updated — automate with Dependabot or Snyk

---

## 6. Monitoring & Incident Response

**Logging**
- Log all authentication events (login, logout, failed attempts, 2FA)
- Log all prediction submissions and modifications
- Log all payment events
- NEVER log passwords, tokens, or full card numbers
- Use structured logging (JSON) for easy analysis

**Real-Time Alerts**
- Alert on: 10+ failed logins from one IP in 5 minutes
- Alert on: unusual prediction volume (bot detection)
- Alert on: payment webhook failures
- Alert on: any admin panel access
- Use PagerDuty, Opsgenie, or Slack webhooks for notifications

**Regular Audits**
- Quarterly penetration testing by an external firm
- Monthly dependency vulnerability scans
- Annual full security audit
- Bug bounty program (even a simple one via HackerOne)

---

## 7. Winner Selection Integrity

This is the most critical part — if people don't trust the selection process, the whole platform fails.

**Provable Fairness**
- All predictions are timestamped and hashed at submission time
- Prediction hashes can be published to a public blockchain (Ethereum, Polygon) for immutability
- The scoring algorithm is published openly so anyone can verify their score
- Final leaderboard is frozen and published with all data needed to independently verify

**Anti-Cheating**
- One account per verified email (email verification required)
- Phone number verification for the top 100 leaderboard positions
- IP-based detection of multiple accounts (flag, don't auto-ban)
- Manual review of top 10 positions before prize announcement
- Prohibit predictions after match kickoff (server-side time validation, not client-side)

---

## 8. Recommended Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React (Next.js) deployed on Vercel |
| Backend API | Node.js (Express or Fastify) or Python (FastAPI) |
| Database | PostgreSQL with pgcrypto extension |
| Cache / Rate Limiting | Redis |
| Authentication | Auth0 or custom JWT + bcrypt |
| Payments | Stripe (global) + Paystack (Africa) + Flutterwave (Africa) |
| CDN / WAF | Cloudflare Pro |
| Hosting | AWS (EC2 + RDS) or Railway / Render for simplicity |
| Monitoring | Datadog or Sentry + UptimeRobot |
| Secrets | AWS Secrets Manager or Doppler |
| CI/CD | GitHub Actions with automated security scanning |

---

## 9. Pre-Launch Checklist

- [ ] All passwords hashed with bcrypt (12+ rounds)
- [ ] Rate limiting on all auth endpoints
- [ ] CSRF tokens on all state-changing routes
- [ ] All SQL queries parameterized
- [ ] Payment webhooks signature-verified
- [ ] HTTPS enforced with HSTS
- [ ] All security headers configured
- [ ] Prediction immutability enforced server-side
- [ ] Email verification flow working
- [ ] Monitoring and alerting configured
- [ ] Penetration test completed
- [ ] Legal terms and conditions reviewed by a lawyer
- [ ] Land prize documentation verified by independent legal counsel
- [ ] Privacy policy compliant with GDPR and local regulations

---

*This document is a guide. Hire a security-focused backend developer and a lawyer before going live with real users and a real prize.*
