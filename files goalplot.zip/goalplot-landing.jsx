import { useState, useEffect, useRef } from "react";

const COUNTRIES = [
  "🇳🇬","🇧🇷","🇦🇷","🇫🇷","🇩🇪","🇬🇧","🇪🇸","🇵🇹","🇮🇹","🇳🇱","🇧🇪","🇺🇸","🇲🇽","🇨🇦",
  "🇯🇵","🇰🇷","🇦🇺","🇪🇬","🇸🇳","🇬🇭","🇨🇲","🇹🇷","🇨🇴","🇺🇾","🇨🇭","🇭🇷","🇩🇰","🇦🇹"
];

const TESTIMONIALS = [
  { name: "Chidi O.", flag: "🇳🇬", text: "I predicted 3 matches correctly on my first day. This is addictive!" },
  { name: "Maria S.", flag: "🇧🇷", text: "Free to play and the land prize is actually real. Documents are verified." },
  { name: "James K.", flag: "🇬🇧", text: "Better than any fantasy football app I've used. The leaderboard is fierce." },
  { name: "Yuki T.", flag: "🇯🇵", text: "Love that I can pay with multiple methods. Smooth experience globally." },
  { name: "Fatima A.", flag: "🇪🇬", text: "My whole friend group is on GoalPlot now. The referral points are great." },
  { name: "Carlos M.", flag: "🇲🇽", text: "The World Cup is in my country and I could win land too? Count me in." },
];

function useCountdown(target) {
  const [t, setT] = useState({ d: 0, h: 0, m: 0, s: 0 });
  useEffect(() => {
    const calc = () => {
      const diff = new Date(target) - new Date();
      if (diff <= 0) return { d: 0, h: 0, m: 0, s: 0 };
      return {
        d: Math.floor(diff / 86400000),
        h: Math.floor((diff % 86400000) / 3600000),
        m: Math.floor((diff % 3600000) / 60000),
        s: Math.floor((diff % 60000) / 1000),
      };
    };
    setT(calc());
    const i = setInterval(() => setT(calc()), 1000);
    return () => clearInterval(i);
  }, [target]);
  return t;
}

function FloatingFlags() {
  const flags = useRef(
    COUNTRIES.map((f, i) => ({
      flag: f,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 16 + Math.random() * 20,
      speed: 12 + Math.random() * 25,
      delay: Math.random() * 8,
      opacity: 0.06 + Math.random() * 0.08,
    }))
  );
  return (
    <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}>
      {flags.current.map((f, i) => (
        <div key={i} style={{
          position: "absolute",
          left: `${f.x}%`,
          top: `${f.y}%`,
          fontSize: f.size,
          opacity: f.opacity,
          animation: `floatFlag ${f.speed}s ease-in-out ${f.delay}s infinite alternate`,
        }}>{f.flag}</div>
      ))}
    </div>
  );
}

function AnimCounter({ target }) {
  const [n, setN] = useState(0);
  const ref = useRef(null);
  const ran = useRef(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !ran.current) {
        ran.current = true;
        let s = 0;
        const step = target / 120;
        const iv = setInterval(() => {
          s += step;
          if (s >= target) { setN(target); clearInterval(iv); }
          else setN(Math.floor(s));
        }, 16);
      }
    }, { threshold: 0.3 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target]);
  return <span ref={ref}>{n.toLocaleString()}</span>;
}

export default function GoalPlotLanding() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const countdown = useCountdown("2026-06-11T00:00:00");

  useEffect(() => {
    const iv = setInterval(() => setActiveTestimonial((a) => (a + 1) % TESTIMONIALS.length), 4000);
    return () => clearInterval(iv);
  }, []);

  const validateEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  return (
    <div style={s.page}>
      <style>{css}</style>

      {/* ═══ URGENCY BAR ═══ */}
      <div style={s.urgencyBar}>
        <span style={s.urgencyDot} />
        <span style={s.urgencyText}>
          🔥 <strong><AnimCounter target={48320} />+ people</strong> have already joined — predictions lock when the tournament starts
        </span>
      </div>

      {/* ═══ HERO ═══ */}
      <section style={s.hero}>
        <FloatingFlags />
        <div style={s.heroGlow} />
        <div style={s.heroGlow2} />

        <div style={s.heroInner}>
          {/* LOGO */}
          <div style={s.logoRow}>
            <span style={{ fontSize: 32 }}>🏆</span>
            <div>
              <div style={s.logoMain}>GOAL<span style={s.logoGold}>PLOT</span></div>
              <div style={s.logoSub}>WORLD CUP 2026 PREDICTION</div>
            </div>
          </div>

          {/* HEADLINE */}
          <h1 style={s.headline}>
            PREDICT THE WORLD CUP.<br />
            <span style={s.headlineGold}>WIN REAL LAND.</span>
          </h1>

          <p style={s.subhead}>
            The #1 prediction platform for FIFA World Cup 2026. Pick match winners,
            predict exact scores, and top the leaderboard to win a verified
            <strong style={{ color: "#C9A55A" }}> 100sqm plot of land</strong>.
            Free to play. 48 teams. 104 matches. One winner.
          </p>

          {/* CTA */}
          <div style={s.ctaBox}>
            {!submitted ? (
              <>
                <div style={s.inputRow}>
                  <input
                    style={s.emailInput}
                    placeholder="Enter your email to join"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  <button
                    style={s.ctaBtn}
                    onClick={() => { if (validateEmail(email)) setSubmitted(true); }}
                  >
                    JOIN FREE →
                  </button>
                </div>
                <div style={s.ctaMeta}>
                  🔒 No spam. No credit card required. Unsubscribe anytime.
                </div>
              </>
            ) : (
              <div style={s.successBox}>
                <div style={{ fontSize: 40, marginBottom: 8 }}>🎉</div>
                <div style={s.successTitle}>You're on the list!</div>
                <div style={s.successSub}>Check your email for next steps. Share GoalPlot and earn 50 bonus points per friend.</div>
                <div style={s.shareRow}>
                  {[
                    { label: "WhatsApp", icon: "💬", color: "#25D366" },
                    { label: "Twitter/X", icon: "𝕏", color: "#1DA1F2" },
                    { label: "Copy Link", icon: "🔗", color: "#C9A55A" },
                  ].map((sh) => (
                    <button key={sh.label} style={{ ...s.shareBtn, borderColor: sh.color, color: sh.color }}>
                      {sh.icon} {sh.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* COUNTDOWN */}
          <div style={s.countdownSection}>
            <div style={s.countdownLabel}>TOURNAMENT STARTS IN</div>
            <div style={s.countdownGrid}>
              {[
                { v: countdown.d, l: "DAYS" },
                { v: countdown.h, l: "HRS" },
                { v: countdown.m, l: "MIN" },
                { v: countdown.s, l: "SEC" },
              ].map((c) => (
                <div key={c.l} style={s.countdownCell}>
                  <div style={s.countdownNum}>{String(c.v || 0).padStart(2, "0")}</div>
                  <div style={s.countdownCellLabel}>{c.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* TRUST STRIP */}
          <div style={s.trustStrip}>
            <span style={s.trustItem}>🔒 256-bit Encrypted</span>
            <span style={s.trustDot}>·</span>
            <span style={s.trustItem}>🌍 190+ Countries</span>
            <span style={s.trustDot}>·</span>
            <span style={s.trustItem}>💳 8 Payment Methods</span>
            <span style={s.trustDot}>·</span>
            <span style={s.trustItem}>📜 Verified Land Docs</span>
          </div>
        </div>
      </section>

      {/* ═══ SOCIAL PROOF TICKER ═══ */}
      <div style={s.ticker}>
        <div style={s.tickerInner}>
          {[...COUNTRIES, ...COUNTRIES, ...COUNTRIES].map((f, i) => (
            <span key={i} style={s.tickerFlag}>{f}</span>
          ))}
        </div>
      </div>

      {/* ═══ 3 STEPS ═══ */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>HOW IT WORKS</h2>
        <div style={s.goldLine} />
        <div style={s.stepsRow}>
          {[
            { n: "01", icon: "📝", title: "Join for Free", desc: "Create your account. No credit card. Takes 30 seconds." },
            { n: "02", icon: "🎯", title: "Predict Matches", desc: "Pick winners, predict scores, choose the champion. Earn points for accuracy." },
            { n: "03", icon: "🏡", title: "Win 100sqm Land", desc: "Top the leaderboard. The land is real, verified, and legally transferred to you." },
          ].map((step, i) => (
            <div key={step.n} style={{ ...s.stepCard, animationDelay: `${i * 0.2}s` }}>
              <div style={s.stepNum}>{step.n}</div>
              <div style={s.stepIcon}>{step.icon}</div>
              <h3 style={s.stepTitle}>{step.title}</h3>
              <p style={s.stepDesc}>{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ═══ PRIZE SPOTLIGHT ═══ */}
      <section style={s.prizeSection}>
        <div style={s.prizeContent}>
          <div style={s.prizeTag}>🏡 THE PRIZE IS REAL</div>
          <h2 style={s.prizeH2}>100 SQM PLOT OF LAND</h2>
          <p style={s.prizeP}>
            Not a voucher. Not a discount. A real, documented plot of land with verified
            title papers. The winner receives full legal ownership transferred within 30 days
            of the final.
          </p>
          <div style={s.prizeGrid}>
            {[
              { icon: "📄", label: "Title Documents" },
              { icon: "📐", label: "Survey Plan" },
              { icon: "⚖️", label: "Legal Transfer" },
              { icon: "🔍", label: "Independent Audit" },
              { icon: "📡", label: "Live Announcement" },
              { icon: "🔗", label: "Blockchain Verified" },
            ].map((p) => (
              <div key={p.label} style={s.prizeItem}>
                <span style={{ fontSize: 24 }}>{p.icon}</span>
                <span style={s.prizeItemLabel}>{p.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ TESTIMONIALS ═══ */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>WHAT PREDICTORS SAY</h2>
        <div style={s.goldLine} />
        <div style={s.testimonialCard}>
          <div style={s.testimonialQuote}>"{TESTIMONIALS[activeTestimonial].text}"</div>
          <div style={s.testimonialAuthor}>
            <span style={{ fontSize: 24 }}>{TESTIMONIALS[activeTestimonial].flag}</span>
            <span style={s.testimonialName}>{TESTIMONIALS[activeTestimonial].name}</span>
          </div>
          <div style={s.testimonialDots}>
            {TESTIMONIALS.map((_, i) => (
              <div
                key={i}
                style={{ ...s.dot, background: i === activeTestimonial ? "#C9A55A" : "rgba(255,255,255,0.1)" }}
                onClick={() => setActiveTestimonial(i)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ═══ STATS BAR ═══ */}
      <section style={s.statsBar}>
        {[
          { num: 48320, label: "Predictors Joined", suffix: "+" },
          { num: 104, label: "Matches to Predict", suffix: "" },
          { num: 48, label: "Teams Competing", suffix: "" },
          { num: 190, label: "Countries Represented", suffix: "+" },
        ].map((st) => (
          <div key={st.label} style={s.statsItem}>
            <div style={s.statsNum}><AnimCounter target={st.num} />{st.suffix}</div>
            <div style={s.statsLabel}>{st.label}</div>
          </div>
        ))}
      </section>

      {/* ═══ URGENCY CTA ═══ */}
      <section style={s.finalCta}>
        <div style={s.finalCtaInner}>
          <h2 style={s.finalH2}>DON'T MISS YOUR SHOT</h2>
          <p style={s.finalP}>
            Predictions lock when the first match kicks off.
            Join now and secure your place on the leaderboard.
          </p>
          <button style={s.finalBtn} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
            JOIN GOALPLOT FREE →
          </button>
          <div style={s.finalMeta}>Free forever · No credit card · Takes 30 seconds</div>
        </div>
      </section>

      {/* ═══ FOOTER ═══ */}
      <footer style={s.footer}>
        <div style={s.footerTop}>
          <div>
            <span style={{ fontSize: 24 }}>🏆</span>{" "}
            <span style={s.footerLogo}>GOAL<span style={{ color: "#C9A55A" }}>PLOT</span></span>
          </div>
          <div style={s.footerLinks}>
            {["Terms", "Privacy", "Rules", "Contact", "Advertise"].map((l) => (
              <span key={l} style={s.footerLink}>{l}</span>
            ))}
          </div>
        </div>
        <div style={s.footerBottom}>
          © 2026 GoalPlot. All rights reserved. Not affiliated with FIFA or the FIFA World Cup™.
          <br />This is an independent prediction platform. Play responsibly.
        </div>
      </footer>
    </div>
  );
}

const css = `
@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;500;600;700;800;900&family=Noto+Sans:wght@300;400;500;600;700&family=Bebas+Neue&display=swap');
* { box-sizing: border-box; margin: 0; padding: 0; }
@keyframes floatFlag { 0% { transform: translateY(0) rotate(0deg); } 100% { transform: translateY(-30px) rotate(8deg); } }
@keyframes fadeUp { from { opacity:0; transform:translateY(20px) } to { opacity:1; transform:translateY(0) } }
@keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(201,165,90,0.4); } 50% { box-shadow: 0 0 0 14px rgba(201,165,90,0); } }
@keyframes scroll { 0% { transform: translateX(0); } 100% { transform: translateX(-33.33%); } }
@keyframes glow { 0%,100% { opacity: 0.6; } 50% { opacity: 1; } }
`;

const s = {
  page: { fontFamily: "'Noto Sans', sans-serif", background: "#06090F", color: "#D0D0D0", minHeight: "100vh", overflowX: "hidden" },

  /* URGENCY BAR */
  urgencyBar: { background: "linear-gradient(90deg, #1a0f00, #0f1a00)", borderBottom: "1px solid rgba(201,165,90,0.15)", padding: "10px 20px", display: "flex", alignItems: "center", justifyContent: "center", gap: 10, fontSize: 13 },
  urgencyDot: { width: 8, height: 8, borderRadius: "50%", background: "#E74C4C", animation: "glow 1.5s infinite", flexShrink: 0 },
  urgencyText: { color: "#B0A080" },

  /* HERO */
  hero: { position: "relative", padding: "60px 24px 48px", textAlign: "center", overflow: "hidden", minHeight: "90vh", display: "flex", alignItems: "center", justifyContent: "center" },
  heroGlow: { position: "absolute", top: "-100px", left: "50%", transform: "translateX(-50%)", width: 900, height: 600, background: "radial-gradient(ellipse, rgba(201,165,90,0.07) 0%, transparent 65%)", pointerEvents: "none" },
  heroGlow2: { position: "absolute", bottom: "-200px", left: "50%", transform: "translateX(-50%)", width: 700, height: 500, background: "radial-gradient(ellipse, rgba(60,172,59,0.04) 0%, transparent 65%)", pointerEvents: "none" },
  heroInner: { position: "relative", maxWidth: 720, margin: "0 auto", zIndex: 2 },

  /* LOGO */
  logoRow: { display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 36, animation: "fadeUp 0.5s ease both" },
  logoMain: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: 28, color: "#fff", letterSpacing: 3, lineHeight: 1 },
  logoGold: { color: "#C9A55A" },
  logoSub: { fontFamily: "'Barlow Condensed', sans-serif", fontSize: 10, fontWeight: 600, letterSpacing: 4, color: "#6B5C3E", lineHeight: 1 },

  /* HEADLINE */
  headline: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: "clamp(40px, 8vw, 72px)", lineHeight: 1.0, color: "#fff", letterSpacing: 2, marginBottom: 20, animation: "fadeUp 0.7s ease both" },
  headlineGold: { background: "linear-gradient(135deg, #E8D5A3, #C9A55A, #8B6F2E)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" },

  /* SUBHEAD */
  subhead: { fontSize: 16, lineHeight: 1.8, color: "#8899AA", maxWidth: 540, margin: "0 auto 32px", animation: "fadeUp 0.9s ease both" },

  /* CTA */
  ctaBox: { maxWidth: 480, margin: "0 auto 32px", animation: "fadeUp 1.1s ease both" },
  inputRow: { display: "flex", gap: 0, borderRadius: 12, overflow: "hidden", border: "2px solid rgba(201,165,90,0.25)", background: "rgba(255,255,255,0.03)" },
  emailInput: { flex: 1, padding: "16px 18px", background: "transparent", border: "none", color: "#fff", fontSize: 15, fontFamily: "'Noto Sans', sans-serif", outline: "none", minWidth: 0 },
  ctaBtn: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: 15, letterSpacing: 1.5, background: "linear-gradient(135deg, #C9A55A, #8B6F2E)", color: "#000", border: "none", padding: "16px 28px", cursor: "pointer", whiteSpace: "nowrap", transition: "all 0.25s", animation: "pulse 2s infinite" },
  ctaMeta: { fontSize: 12, color: "#556677", marginTop: 10, textAlign: "center" },

  /* SUCCESS */
  successBox: { background: "rgba(60,172,59,0.06)", border: "1px solid rgba(60,172,59,0.15)", borderRadius: 16, padding: "28px 24px", textAlign: "center" },
  successTitle: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: 26, color: "#fff", letterSpacing: 2, marginBottom: 8 },
  successSub: { fontSize: 14, color: "#8899AA", marginBottom: 20 },
  shareRow: { display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" },
  shareBtn: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 13, letterSpacing: 1, background: "transparent", border: "1.5px solid", padding: "10px 18px", borderRadius: 8, cursor: "pointer" },

  /* COUNTDOWN */
  countdownSection: { marginBottom: 28, animation: "fadeUp 1.3s ease both" },
  countdownLabel: { fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, fontWeight: 700, letterSpacing: 4, color: "#556677", marginBottom: 10 },
  countdownGrid: { display: "inline-flex", gap: 10 },
  countdownCell: { background: "rgba(255,255,255,0.03)", border: "1px solid rgba(201,165,90,0.1)", borderRadius: 10, padding: "14px 18px", minWidth: 66, textAlign: "center" },
  countdownNum: { fontFamily: "'Bebas Neue', sans-serif", fontSize: 32, color: "#C9A55A", lineHeight: 1 },
  countdownCellLabel: { fontSize: 9, fontWeight: 700, letterSpacing: 2, color: "#556677", marginTop: 4 },

  /* TRUST */
  trustStrip: { display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap", animation: "fadeUp 1.5s ease both" },
  trustItem: { fontSize: 12, color: "#556677", fontWeight: 600 },
  trustDot: { color: "#333" },

  /* TICKER */
  ticker: { overflow: "hidden", padding: "14px 0", borderTop: "1px solid rgba(255,255,255,0.04)", borderBottom: "1px solid rgba(255,255,255,0.04)", background: "rgba(201,165,90,0.02)" },
  tickerInner: { display: "flex", gap: 20, animation: "scroll 30s linear infinite", width: "max-content" },
  tickerFlag: { fontSize: 22 },

  /* SECTIONS */
  section: { maxWidth: 900, margin: "0 auto", padding: "64px 24px" },
  sectionTitle: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: 34, color: "#fff", textAlign: "center", letterSpacing: 3 },
  goldLine: { width: 50, height: 3, background: "#C9A55A", margin: "12px auto 36px", borderRadius: 2 },

  /* STEPS */
  stepsRow: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 20 },
  stepCard: { background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 16, padding: "32px 24px", textAlign: "center", animation: "fadeUp 0.6s ease both", transition: "border-color 0.3s, transform 0.3s" },
  stepNum: { fontFamily: "'Bebas Neue', sans-serif", fontSize: 40, color: "rgba(201,165,90,0.1)", lineHeight: 1, marginBottom: -4 },
  stepIcon: { fontSize: 36, marginBottom: 12 },
  stepTitle: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: 20, color: "#fff", letterSpacing: 1, marginBottom: 8 },
  stepDesc: { fontSize: 13, lineHeight: 1.7, color: "#7788AA" },

  /* PRIZE */
  prizeSection: { background: "linear-gradient(180deg, rgba(201,165,90,0.04) 0%, rgba(6,9,15,1) 100%)", padding: "64px 24px", textAlign: "center" },
  prizeContent: { maxWidth: 700, margin: "0 auto" },
  prizeTag: { display: "inline-block", background: "rgba(201,165,90,0.1)", border: "1px solid rgba(201,165,90,0.2)", borderRadius: 100, padding: "6px 20px", fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 13, color: "#C9A55A", letterSpacing: 2, marginBottom: 20 },
  prizeH2: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: "clamp(36px,6vw,56px)", color: "#fff", letterSpacing: 3, marginBottom: 16 },
  prizeP: { fontSize: 15, lineHeight: 1.8, color: "#8899AA", maxWidth: 520, margin: "0 auto 32px" },
  prizeGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 },
  prizeItem: { display: "flex", flexDirection: "column", alignItems: "center", gap: 6, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 12, padding: "18px 12px" },
  prizeItemLabel: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 13, color: "#AAA", letterSpacing: 0.5 },

  /* TESTIMONIALS */
  testimonialCard: { maxWidth: 520, margin: "0 auto", background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 20, padding: "36px 28px", textAlign: "center" },
  testimonialQuote: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 600, fontSize: 20, color: "#fff", lineHeight: 1.5, marginBottom: 20, letterSpacing: 0.5, minHeight: 60 },
  testimonialAuthor: { display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 16 },
  testimonialName: { fontWeight: 700, fontSize: 14, color: "#C9A55A" },
  testimonialDots: { display: "flex", gap: 8, justifyContent: "center" },
  dot: { width: 8, height: 8, borderRadius: "50%", cursor: "pointer", transition: "background 0.3s" },

  /* STATS */
  statsBar: { display: "flex", justifyContent: "center", gap: 40, flexWrap: "wrap", padding: "48px 24px", borderTop: "1px solid rgba(255,255,255,0.04)", borderBottom: "1px solid rgba(255,255,255,0.04)" },
  statsItem: { textAlign: "center", minWidth: 120 },
  statsNum: { fontFamily: "'Bebas Neue', sans-serif", fontSize: 40, color: "#C9A55A", letterSpacing: 1 },
  statsLabel: { fontSize: 12, color: "#556677", fontWeight: 600, letterSpacing: 1, textTransform: "uppercase", marginTop: 4 },

  /* FINAL CTA */
  finalCta: { padding: "72px 24px", textAlign: "center" },
  finalCtaInner: { maxWidth: 550, margin: "0 auto" },
  finalH2: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: "clamp(32px,5vw,48px)", color: "#fff", letterSpacing: 3, marginBottom: 16 },
  finalP: { fontSize: 16, color: "#8899AA", lineHeight: 1.7, marginBottom: 28 },
  finalBtn: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: 18, letterSpacing: 2, background: "linear-gradient(135deg, #C9A55A, #8B6F2E)", color: "#000", border: "none", padding: "18px 48px", borderRadius: 12, cursor: "pointer", animation: "pulse 2s infinite", transition: "all 0.25s" },
  finalMeta: { fontSize: 13, color: "#556677", marginTop: 14 },

  /* FOOTER */
  footer: { borderTop: "1px solid rgba(255,255,255,0.04)", padding: "28px 24px", maxWidth: 900, margin: "0 auto" },
  footerTop: { display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16, marginBottom: 16 },
  footerLogo: { fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 900, fontSize: 20, color: "#fff", letterSpacing: 2 },
  footerLinks: { display: "flex", gap: 20, flexWrap: "wrap" },
  footerLink: { fontSize: 13, color: "#556677", cursor: "pointer" },
  footerBottom: { fontSize: 11, color: "#333", lineHeight: 1.7, textAlign: "center" },
};
