# GoalPlot — Privacy Policy

**Last Updated: [DATE]**
**Effective Date: [DATE]**

---

## 1. Who We Are

GoalPlot is operated by [YOUR COMPANY NAME] ("Company," "we," "us," or "our"), registered in [COUNTRY] with registration number [NUMBER].

**Data Controller Contact:**
Email: privacy@goalplot.com
Address: [PHYSICAL ADDRESS]

---

## 2. What Data We Collect

### 2.1 Data You Provide

| Data Type | When Collected | Purpose |
|-----------|---------------|---------|
| Username | Registration | Account identification, leaderboard display |
| Email address | Registration | Account access, notifications, winner contact |
| Password (hashed) | Registration | Authentication (stored as bcrypt hash, never plain text) |
| Phone number (optional) | Top-100 verification | Anti-fraud, winner verification |
| Country/region | Registration | Localization, legal compliance |
| Payment information | VIP upgrade | Processed by third-party providers (see Section 5) |
| Predictions | Platform use | Core service functionality |
| Referral activity | Sharing referral link | Bonus point allocation |

### 2.2 Data We Collect Automatically

| Data Type | Purpose |
|-----------|---------|
| IP address | Security, rate limiting, fraud detection |
| Browser type and version | Compatibility, security |
| Device type | Responsive experience |
| Pages visited and timestamps | Analytics, service improvement |
| Cookies and similar technologies | Session management, preferences (see Section 7) |

### 2.3 Data We Do NOT Collect

- Credit card numbers or bank account details (handled entirely by payment providers)
- Government ID numbers (only requested from the winner during prize verification)
- Biometric data
- Health or medical data
- Data from minors (the Platform is restricted to users 18+)

---

## 3. Why We Use Your Data (Legal Basis)

Under GDPR and equivalent regulations, we process your data based on the following legal grounds:

| Purpose | Legal Basis |
|---------|-------------|
| Providing the prediction service | Performance of contract (you agree to Terms when registering) |
| Processing payments | Performance of contract |
| Sending transactional emails (account confirmation, password reset, winner notification) | Performance of contract |
| Fraud prevention and security | Legitimate interest |
| Analytics and service improvement | Legitimate interest |
| Marketing emails and newsletters | Your consent (opt-in) |
| Legal compliance (tax, contest regulations) | Legal obligation |

---

## 4. How We Protect Your Data

- **Encryption in transit:** All data transmitted between your browser and our servers is encrypted using TLS 1.3.
- **Encryption at rest:** Database encrypted using AES-256.
- **Password security:** Passwords are hashed using bcrypt with a minimum of 12 salt rounds. We never store, log, or transmit plain-text passwords.
- **Access control:** Employee access to user data is restricted to essential personnel only, protected by 2FA and audit logging.
- **Infrastructure:** Hosted on [AWS/GCP/etc.] with DDoS protection via Cloudflare. Regular security patches and updates applied.
- **Monitoring:** Real-time intrusion detection and anomaly alerting.
- **Audits:** Regular third-party security audits and penetration testing.

---

## 5. Third-Party Data Processors

We share data with the following categories of third-party processors, strictly for the purposes described:

| Provider Category | Examples | Data Shared | Purpose |
|------------------|----------|-------------|---------|
| Payment processors | Stripe, PayPal, Paystack, Flutterwave | Payment tokens (NOT card numbers) | Processing VIP tier payments |
| Email service | [e.g., SendGrid, Mailgun] | Email address, username | Transactional and marketing emails |
| Analytics | [e.g., PostHog, Plausible, Google Analytics] | Anonymized usage data | Service improvement |
| Cloud hosting | [e.g., AWS, Vercel] | All data (encrypted) | Infrastructure |
| CDN/Security | Cloudflare | IP address, request metadata | DDoS protection, caching |

We do NOT sell, rent, or trade your personal data to any third party for advertising or marketing purposes.

All third-party processors are contractually required to protect your data to standards equivalent to this Privacy Policy.

---

## 6. Your Rights

Depending on your jurisdiction, you have the following rights:

### All Users
- **Access:** Request a copy of all personal data we hold about you.
- **Correction:** Request correction of inaccurate data.
- **Deletion:** Request deletion of your account and personal data ("right to be forgotten").
- **Data portability:** Request your data in a machine-readable format (JSON or CSV).
- **Withdraw consent:** Withdraw consent for marketing communications at any time.
- **Object:** Object to processing based on legitimate interest.

### EU/EEA Users (GDPR)
- All rights above, plus the right to lodge a complaint with your national Data Protection Authority.
- Data transfers outside the EEA are protected by Standard Contractual Clauses (SCCs).

### Nigerian Users (NDPR)
- All rights above, in accordance with the Nigeria Data Protection Regulation 2019 and the Nigeria Data Protection Act 2023.

### California Users (CCPA)
- Right to know what personal information is collected, used, and shared.
- Right to delete personal information.
- Right to opt out of the sale of personal information (we do not sell data).
- Right to non-discrimination for exercising your rights.

**To exercise any of these rights, contact:** privacy@goalplot.com

We will respond within 30 days (or sooner where required by law).

---

## 7. Cookies

### 7.1 What Cookies We Use

| Cookie Type | Purpose | Duration | Required? |
|-------------|---------|----------|-----------|
| Session cookie | Keeps you logged in | Browser session | Essential |
| CSRF token | Security (prevents cross-site attacks) | Browser session | Essential |
| Preferences | Remembers language, theme | 1 year | Functional |
| Analytics | Anonymous usage statistics | 1 year | Optional (consent required) |

### 7.2 Managing Cookies
- Essential cookies cannot be disabled as they are required for the Platform to function.
- Optional cookies (analytics) are only set with your explicit consent.
- You can manage cookie preferences through the cookie banner displayed on your first visit, or through your browser settings.

---

## 8. Data Retention

| Data Type | Retention Period |
|-----------|-----------------|
| Active account data | Retained while your account is active |
| Deleted account data | Permanently deleted within 30 days of account deletion request |
| Prediction history | Retained for 12 months after contest end for verification and audit purposes, then anonymized |
| Payment records | Retained for 7 years as required by tax and financial regulations |
| Server logs (IP, requests) | Retained for 90 days, then deleted |
| Marketing consent records | Retained for as long as consent is active, plus 3 years after withdrawal for legal compliance |

---

## 9. International Data Transfers

If you are located outside the country where our servers are hosted, your data may be transferred internationally. We ensure adequate protection through:

- Standard Contractual Clauses (SCCs) approved by the European Commission
- Data Processing Agreements (DPAs) with all third-party processors
- Encryption of all data in transit and at rest

---

## 10. Children's Privacy

The Platform is not intended for users under 18 years of age. We do not knowingly collect personal data from children. If we discover that a user is under 18, their account will be immediately terminated and all associated data deleted.

If you believe a child has created an account, contact us at privacy@goalplot.com.

---

## 11. Changes to This Policy

We may update this Privacy Policy from time to time. Material changes will be communicated via:

- Email notification to registered users
- Prominent notice on the Platform
- Updated "Last Updated" date at the top of this document

Changes take effect 14 days after notification. Continued use of the Platform after that date constitutes acceptance.

---

## 12. Data Breach Notification

In the event of a personal data breach that poses a risk to your rights and freedoms:

- We will notify affected users within 72 hours of discovery (as required by GDPR).
- We will notify the relevant Data Protection Authority where required by law.
- Notification will include the nature of the breach, data affected, steps taken, and recommended actions for you.

---

## 13. Contact Us

For any privacy-related questions, requests, or complaints:

**Data Protection Contact**
Email: privacy@goalplot.com
Address: [PHYSICAL ADDRESS]
Response time: Within 30 days

If you are unsatisfied with our response, you have the right to lodge a complaint with your local Data Protection Authority.

---

*IMPORTANT: This document is a template and does NOT constitute legal advice. Have this reviewed by a qualified privacy lawyer before publishing, especially if you operate in or serve users from the EU, Nigeria, California, Brazil, or other jurisdictions with specific data protection legislation.*
