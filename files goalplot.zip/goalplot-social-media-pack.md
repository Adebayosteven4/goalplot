# GoalPlot — Social Media Content Pack

---

## Brand Voice

**Tone:** Bold, confident, hype-driven. Like a sports commentator who also understands business.
**Style:** Short punchy sentences. Emojis used strategically (not excessively). Urgency without desperation. Gold and trophy imagery woven throughout.
**Key phrases to repeat:** "Free to play", "Real land", "100sqm", "Predict. Compete. Win.", "Your predictions. Your land."

---

## Platform Strategy

| Platform | Content Type | Post Frequency | Audience |
|----------|-------------|----------------|----------|
| Instagram | Reels, carousels, stories | Daily | 18-35, global, visual-first |
| Twitter/X | Text posts, polls, threads | 3-5x daily | Sports fans, crypto/tech |
| TikTok | Short videos, trends | Daily | 18-28, viral potential |
| Facebook | Ads, groups, events | 3x weekly | 25-45, Africa, LatAm |
| WhatsApp | Status updates, group shares | 2x weekly | Nigeria, Africa, referral engine |
| YouTube | Explainer video, winner announcement | Weekly | All ages, trust building |

---

## Launch Phase Ads (Pre-Tournament)

### Ad Set 1: Awareness — "The Prize Is Real"

**Instagram / Facebook Ad:**

Headline: PREDICT THE WORLD CUP. WIN REAL LAND.

Body:
GoalPlot is the #1 prediction platform for FIFA World Cup 2026.

Pick match winners. Predict exact scores. Top the leaderboard.

The prize? A verified 100sqm plot of land. Real title documents. Real legal transfer.

Free to play. No catch.

48 teams. 104 matches. 1 winner.

Join 48,000+ predictors now.

CTA Button: JOIN FREE

---

**Twitter/X Version:**

Most prediction apps give you bragging rights.

We give you land.

Predict the 2026 World Cup winner. Top the leaderboard. Win a verified 100sqm plot of land.

Free to play. Real prize.

goalplot.com

---

**TikTok Script (15 sec):**

[Hook — text on screen]: "What if your World Cup predictions could win you LAND?"

[Cut to phone screen showing GoalPlot]

"GoalPlot lets you predict every match of the 2026 World Cup. The person with the most points wins a REAL 100sqm plot of land. Not a gift card. Not cash. LAND."

[Text overlay]: "Free to play. Link in bio."

---

### Ad Set 2: Urgency — "Predictions Lock Soon"

**Instagram Story Ad:**

Frame 1: "48,000+ people have already joined GoalPlot" [gold text, black bg]
Frame 2: "They're predicting the 2026 World Cup winner" [show app screenshot]
Frame 3: "The top predictor wins 100sqm of REAL LAND" [show land doc]
Frame 4: "Predictions lock when the tournament starts" [countdown timer]
Frame 5: "Join free before it's too late" [CTA: Swipe Up]

---

**Facebook Ad:**

Headline: Predictions Lock June 11th

Body:
The 2026 World Cup kicks off in [X] days.

48,320 people are already making their predictions on GoalPlot.

The #1 predictor at the end of the tournament wins a verified 100sqm plot of land.

Free to play. Real prize. Real documents.

Don't miss your chance.

CTA: JOIN BEFORE LOCKOUT

---

### Ad Set 3: Social Proof — "Everyone's Talking About It"

**Instagram Carousel:**

Slide 1: "Why 48,000+ people are obsessed with GoalPlot"
Slide 2: Screenshot of leaderboard + "Real-time rankings"
Slide 3: Screenshot of prediction interface + "Predict every match"
Slide 4: Land document mockup + "The prize is REAL"
Slide 5: "Free to play. Join now. goalplot.com"

---

**Twitter/X Thread:**

Tweet 1:
I just found a platform where you predict World Cup matches and the winner gets actual land.

Not a joke. Not crypto. A real 100sqm plot with verified title documents.

It's called GoalPlot. Thread below.

Tweet 2:
How it works:
- Sign up free
- Predict match winners (+ exact scores if you go VIP)
- Earn points for correct predictions
- Top the leaderboard
- Win the land

Simple.

Tweet 3:
The security is serious too:
- 256-bit encryption
- CSRF protection
- Blockchain-verified prediction records
- Independent prize auditing

This isn't some random WhatsApp scam.

Tweet 4:
Payment options if you want VIP:
- Stripe (global)
- PayPal
- Paystack (Africa)
- Flutterwave
- M-Pesa
- Crypto

$9.99 gets you 2x points on every prediction.

Tweet 5:
48,000+ people have already joined.

The tournament starts June 11.

Predictions lock at kickoff.

goalplot.com

---

## Engagement Posts (During Tournament)

### Match Day Posts

**Template — Pre-Match:**

MATCH DAY

[Team A flag] [Team A] vs [Team B] [Team B flag]

[Time] · [Stadium]

Who you got?

Make your prediction now: goalplot.com

---

**Template — Post-Match:**

FULL TIME

[Team A flag] [Score] - [Score] [Team B flag]

[X,XXX] GoalPlot users predicted this correctly.

Were you one of them? Check your points.

---

**Template — Upset Result:**

NOBODY SAW THAT COMING

[Losing favorite flag] went DOWN.

Only [X%] of GoalPlot users predicted this upset.

If you got it right, you just jumped the leaderboard.

---

### Weekly Leaderboard Update

Every Monday post:

WEEKLY LEADERBOARD UPDATE

Current top 5:
1. [flag] [username] — [X,XXX] pts
2. [flag] [username] — [X,XXX] pts
3. [flag] [username] — [X,XXX] pts
4. [flag] [username] — [X,XXX] pts
5. [flag] [username] — [X,XXX] pts

The race for the land is TIGHT.

Where are YOU? Check your rank: goalplot.com

---

### Polls (Twitter/X)

Poll 1: "Who's winning the World Cup?"
- Argentina
- France
- Brazil
- England

Poll 2: "What would you do with a free 100sqm plot of land?"
- Build a house
- Sell it
- Hold it as investment
- Gift it to family

Poll 3: "Group of Death — which team gets ELIMINATED?"
- [Team A]
- [Team B]
- [Team C]
- [Team D]

---

## Referral Campaign

**WhatsApp Shareable Message:**

Yo! I just joined GoalPlot — it's a free World Cup prediction platform where the top predictor wins a REAL 100sqm plot of land. Not joking. Sign up with my link and we both get bonus points: goalplot.com/ref/[USERNAME]

---

**Instagram Story Template for Users to Share:**

"I'm on GoalPlot predicting the World Cup

The prize? A 100sqm plot of LAND

Join with my link for bonus points

[USERNAME's referral link]"

---

## Content Calendar — Launch Week

| Day | Platform | Post Type | Content |
|-----|----------|-----------|---------|
| Mon | All | Announcement | "GoalPlot is LIVE. Predict the 2026 World Cup. Win land." |
| Mon | Twitter | Thread | How it works thread (5 tweets) |
| Tue | Instagram | Reel | 15-sec explainer "What if your predictions could win you land?" |
| Tue | Twitter | Poll | "Who's winning the World Cup?" |
| Wed | Instagram | Carousel | "5 reasons GoalPlot is different" |
| Wed | Facebook | Ad | Awareness ad — "The Prize Is Real" |
| Thu | TikTok | Video | Show the land documents + "This is what you could win" |
| Thu | Twitter | Post | Leaderboard preview + "48,000 have joined" |
| Fri | Instagram | Story | Countdown to tournament + swipe up to join |
| Fri | All | Post | "Predictions lock in [X] days" urgency post |
| Sat | Instagram | Reel | Behind the scenes: "How we verified the land prize" |
| Sat | Twitter | Thread | Security thread — "How GoalPlot keeps your data safe" |
| Sun | All | Post | "One week to kickoff. Are your predictions in?" |

---

## Hashtags

Primary: #GoalPlot #WorldCup2026 #PredictAndWin
Secondary: #WinLand #WorldCupPredictions #FIFA2026 #FreeLand #FootballPredictions
Trending (use during matches): #[TeamA]vs[TeamB] #WorldCup #WC2026

---

## Influencer Outreach Template

Subject: Collab with GoalPlot — World Cup 2026 Prediction Platform

Hi [Name],

GoalPlot is a free prediction platform for the 2026 FIFA World Cup where the top predictor wins a verified 100sqm plot of land.

We'd love to partner with you to spread the word. Here's what we're offering:

- Unique referral link (you earn per signup)
- Custom promo code for your audience
- Feature on our leaderboard page
- [X amount] sponsorship fee for [X posts]

48,000+ users have already joined and we're growing fast.

Interested? Let's chat.

Best,
[Your Name]
GoalPlot Team

---

*All copy should be localized for key markets (Nigeria: Pidgin English versions, Brazil: Portuguese, Mexico: Spanish, France: French). Consider hiring local social media managers for top 5 markets.*
