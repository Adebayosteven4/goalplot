# GoalPlot — Terms and Conditions

**Last Updated: [DATE]**
**Effective Date: [DATE]**

---

## 1. Introduction and Acceptance

These Terms and Conditions ("Terms") govern your use of the GoalPlot prediction platform ("Platform"), operated by [YOUR COMPANY NAME], a company registered in [COUNTRY/STATE] with registration number [NUMBER] ("Company," "we," "us," or "our").

By creating an account, accessing, or using the Platform, you agree to be bound by these Terms. If you do not agree, do not use the Platform.

---

## 2. Eligibility

2.1. You must be at least 18 years of age (or the legal age of majority in your jurisdiction, whichever is greater) to use the Platform.

2.2. You must provide accurate, complete, and current registration information.

2.3. Employees, officers, directors, and immediate family members of the Company and its affiliates are not eligible to win the Grand Prize.

2.4. Participation is void where prohibited or restricted by local law. It is your sole responsibility to determine whether your participation is lawful in your jurisdiction.

2.5. Only one (1) account per person is permitted. Multiple accounts will result in disqualification.

---

## 3. The Prediction Contest

3.1. **Nature of Contest.** GoalPlot is a free-to-enter skill-based prediction contest. It is NOT gambling, betting, or a game of chance. No purchase is necessary to enter or win the Grand Prize.

3.2. **How It Works.** Participants predict outcomes of FIFA World Cup 2026 matches. Points are awarded based on prediction accuracy according to the Scoring System (Section 4).

3.3. **Contest Period.** The contest begins on [START DATE] and ends upon completion of the FIFA World Cup 2026 Final match ("Contest Period").

3.4. **Predictions are Final.** Predictions may be modified up to one (1) hour before the scheduled kickoff time of each match. After that deadline, predictions for that match are locked and immutable. The tournament winner prediction locks when the first group stage match kicks off.

---

## 4. Scoring System

4.1. Points are awarded as follows:

- Correct match winner prediction: 10 points
- Correct draw prediction: 10 points
- Correct exact score prediction (VIP only): 30 points
- Correct group stage winner: 50 points
- Correct tournament winner: 200 points
- Correct top scorer prediction (VIP only): 100 points

4.2. VIP tier members receive the following multipliers applied to all points earned:

- Golden Boot tier: 2× multiplier
- World Champion tier: 5× multiplier

4.3. Referral bonus: 50 points per referred user who registers and submits at least one prediction.

4.4. The Company reserves the right to modify the scoring system with reasonable notice. Any changes will be announced on the Platform and will not retroactively affect points already earned.

---

## 5. The Grand Prize

5.1. **Prize Description.** The Grand Prize is one (1) plot of land measuring approximately one hundred (100) square meters, located at [SPECIFIC LOCATION TO BE ANNOUNCED].

5.2. **Prize Details.** Full details of the land plot, including location, survey plan, and title documentation, will be published on the Platform no later than [DATE — suggest at least 30 days before tournament].

5.3. **Winner Determination.** The participant with the highest total points at the conclusion of the Contest Period wins the Grand Prize. In the event of a tie, the participant who submitted their predictions earliest (based on server timestamps) will be declared the winner.

5.4. **Winner Announcement.** The winner will be announced within seven (7) days of the FIFA World Cup 2026 Final. Announcement will be made via the Platform, email, and the Company's official social media channels.

5.5. **Verification.** The winner must complete identity verification within fourteen (14) days of notification, including providing government-issued photo identification, proof of age, and proof of address.

5.6. **Prize Transfer.** Legal transfer of the land title will be completed within thirty (30) days of successful winner verification, subject to applicable legal processes and government requirements in the jurisdiction where the land is located.

5.7. **Taxes and Fees.** The winner is solely responsible for all taxes, duties, transfer fees, legal fees, and any other costs associated with accepting and registering the land prize. The Company will provide all necessary documentation to facilitate the transfer but is not responsible for costs incurred by the winner.

5.8. **No Cash Alternative.** The prize is non-transferable and no cash or other alternative will be offered, unless the Company determines in its sole discretion that a cash equivalent is appropriate.

5.9. **Independent Verification.** The land title, survey documents, and Certificate of Occupancy (or equivalent in the relevant jurisdiction) will be made available for independent verification by the winner or their legal representative before transfer.

---

## 6. VIP / Premium Tiers

6.1. The Platform offers optional paid tiers ("Golden Boot" and "World Champion") that provide enhanced features and point multipliers.

6.2. **No Purchase Necessary.** Purchasing a premium tier is NOT required to enter the contest or win the Grand Prize. The free tier provides full access to the core prediction contest.

6.3. **Pricing.** Current pricing is displayed on the Platform. Prices are in US Dollars unless otherwise stated. Local currency equivalents may vary based on payment provider exchange rates.

6.4. **Payment Processing.** Payments are processed by third-party payment providers (Stripe, PayPal, Paystack, Flutterwave, and others). The Company does not store credit card numbers or bank account details.

6.5. **Refund Policy.** Premium tier purchases are non-refundable once the Contest Period has begun. Purchases made before the Contest Period may be refunded within seven (7) days of purchase.

---

## 7. Referral Program

7.1. Registered users may invite others using a unique referral link.

7.2. The referrer earns 50 bonus points for each referred user who registers and submits at least one prediction.

7.3. Self-referrals, fake accounts, and abuse of the referral system will result in forfeiture of all referral points and potential account suspension.

7.4. There is no cash value associated with referral points.

---

## 8. User Conduct and Anti-Cheating

8.1. You agree not to:

- Create multiple accounts
- Use automated tools, bots, or scripts to submit predictions
- Attempt to manipulate the leaderboard through any dishonest means
- Share your account credentials with others
- Exploit bugs or vulnerabilities in the Platform
- Harass, threaten, or abuse other users or Company staff

8.2. **Detection and Enforcement.** The Company employs technical measures to detect cheating, including but not limited to IP analysis, behavioral analytics, and device fingerprinting. Suspected violations will be investigated.

8.3. **Penalties.** Violations may result in point deduction, account suspension, permanent ban, and/or disqualification from the contest, at the Company's sole discretion.

8.4. **Top Leaderboard Verification.** The top [10] participants on the leaderboard at the end of the Contest Period may be required to complete additional verification, including phone verification and identity confirmation.

---

## 9. Intellectual Property

9.1. All content, design, code, logos, and branding on the Platform are the property of the Company and protected by applicable intellectual property laws.

9.2. "GoalPlot" is a trademark of [YOUR COMPANY NAME]. The Platform is not affiliated with, endorsed by, or connected to FIFA, the FIFA World Cup, or any national football association.

9.3. FIFA World Cup™ is a trademark of FIFA. All team names and emblems are the property of their respective owners.

---

## 10. Privacy and Data Protection

10.1. Your use of the Platform is also governed by our Privacy Policy, available at [URL].

10.2. We collect and process personal data as described in the Privacy Policy, including name, email address, IP address, prediction history, and payment information (processed by third-party providers).

10.3. We comply with applicable data protection laws, including the General Data Protection Regulation (GDPR) for users in the European Economic Area, the Nigeria Data Protection Regulation (NDPR) for Nigerian users, and equivalent legislation in other jurisdictions.

10.4. You have the right to access, correct, delete, or port your personal data. Contact [EMAIL] to exercise these rights.

---

## 11. Disclaimers and Limitation of Liability

11.1. The Platform is provided "AS IS" and "AS AVAILABLE." We make no warranties, express or implied, regarding the Platform's availability, accuracy, or fitness for a particular purpose.

11.2. To the maximum extent permitted by law, the Company's total liability to you for any claims arising from or related to the Platform or these Terms shall not exceed the amount you paid to the Company (if any) in the twelve (12) months preceding the claim.

11.3. The Company is not responsible for losses arising from internet connectivity issues, server failures, or technical problems that may affect your ability to submit predictions.

11.4. The Company is not responsible for changes to the FIFA World Cup 2026 schedule, format, or cancellation of matches or the tournament.

---

## 12. Dispute Resolution

12.1. Any dispute arising from these Terms shall first be submitted to good-faith negotiation for a period of thirty (30) days.

12.2. If negotiation fails, disputes shall be resolved by binding arbitration administered by [ARBITRATION BODY] in [CITY, COUNTRY], conducted in English.

12.3. You agree to resolve disputes on an individual basis and waive any right to participate in a class action.

---

## 13. Modifications

13.1. The Company reserves the right to modify these Terms at any time. Material changes will be communicated via email and/or prominent notice on the Platform at least fourteen (14) days before taking effect.

13.2. Continued use of the Platform after changes take effect constitutes acceptance of the modified Terms.

---

## 14. Termination

14.1. You may delete your account at any time by contacting [EMAIL].

14.2. The Company may suspend or terminate your account for violation of these Terms.

14.3. Upon termination, your predictions and contest entry are forfeited.

---

## 15. Governing Law

These Terms are governed by the laws of [JURISDICTION]. Any legal proceedings shall be brought in the courts of [JURISDICTION].

---

## 16. Contact

For questions, concerns, or legal inquiries:

**[YOUR COMPANY NAME]**
Email: [EMAIL]
Address: [PHYSICAL ADDRESS]
Website: [URL]

---

## 17. Severability

If any provision of these Terms is found to be unenforceable, the remaining provisions shall continue in full force and effect.

---

*IMPORTANT: This document is a template and does NOT constitute legal advice. You MUST have this reviewed and customized by a qualified lawyer in your jurisdiction before publishing. Contest and prize laws vary significantly by country and state/province. A lawyer will ensure you comply with local regulations regarding contests, prizes, data protection, consumer rights, and tax obligations.*
