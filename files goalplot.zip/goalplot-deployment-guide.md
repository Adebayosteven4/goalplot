# GoalPlot — Complete Deployment Guide (Zero Budget)

Everything you need to go live. Follow every step in order. Total cost: $10 (domain only).

---

## YOUR FREE TECH STACK

| Service | Cost | What It Does |
|---------|------|-------------|
| Namecheap | $10/year | Domain registration (goalplot.com) |
| Supabase | FREE | Database, user authentication, API |
| Vercel | FREE | Hosting your website |
| Cloudflare | FREE | Security, DDoS protection, CDN |
| Paystack | FREE to setup | Payment processing (2.5% per transaction) |
| Mailchimp | FREE | Email collection (up to 500 contacts) |
| GitHub | FREE | Code storage |

Total monthly cost: $0 (until you outgrow free tiers, which handles ~50,000 users)

---

## STEP 1: Register Your Domain (10 minutes)

1. Go to **https://www.namecheap.com**
2. Create an account
3. Search for **goalplot.com**
4. If available: Add to cart → Checkout → Pay ($10ish)
5. If taken: Try goalplot.io, goalplot.co, goalplot.app, or gogoalplot.com
6. During checkout: Enable **WhoisGuard** (free) — this hides your personal info
7. **DO NOT buy hosting from Namecheap** — we're using Vercel (free)

After purchase, you'll see your domain in your Namecheap dashboard.

---

## STEP 2: Create GitHub Account (5 minutes)

1. Go to **https://github.com**
2. Click **Sign Up**
3. Create account with your email
4. Create a new repository:
   - Click the **+** icon (top right) → **New repository**
   - Name: **goalplot**
   - Set to **Public**
   - Click **Create repository**
5. You'll upload your code here later

---

## STEP 3: Set Up Supabase (15 minutes)

This is your entire backend — database, authentication, API — all free.

1. Go to **https://supabase.com**
2. Click **Start your project** → Sign up with GitHub
3. Click **New project**
   - Organization: Your name
   - Project name: **goalplot**
   - Database password: Create a STRONG password (save it somewhere safe!)
   - Region: Choose closest to your users (e.g., **West EU** for global, or **East US**)
   - Click **Create new project**
4. Wait 2 minutes for it to set up

### Set up the database:
5. In your Supabase dashboard, click **SQL Editor** (left sidebar)
6. Click **New query**
7. Open the file **goalplot-database.sql** that Claude created
8. Copy the ENTIRE contents
9. Paste into the SQL Editor
10. Click **Run** (or Ctrl+Enter)
11. You should see "Success. No rows returned" — that's correct!

### Set up authentication:
12. Click **Authentication** (left sidebar)
13. Click **Providers**
14. **Email** should already be enabled — make sure it is
15. Optionally enable **Google** provider:
    - Toggle it on
    - You'll need Google OAuth credentials (can do this later)

### Get your API keys:
16. Click **Settings** (gear icon, left sidebar)
17. Click **API**
18. Copy these two values and SAVE THEM:
    - **Project URL** (looks like: https://xxxxx.supabase.co)
    - **anon public key** (long string starting with "eyJ...")
    - **DO NOT share the service_role key** — that's the admin key

---

## STEP 4: Set Up Vercel (15 minutes)

1. Go to **https://vercel.com**
2. Click **Sign Up** → **Continue with GitHub**
3. Authorize Vercel to access your GitHub

### Create your project:
4. Click **Add New...** → **Project**
5. Select **Import Git Repository** → Choose your **goalplot** repository
6. Configure:
   - Framework Preset: **Create React App** (or **Vite** if using Vite)
   - Root Directory: leave as **/**
7. Add Environment Variables (click **Environment Variables**):
   - Name: `REACT_APP_SUPABASE_URL` → Value: your Supabase Project URL
   - Name: `REACT_APP_SUPABASE_ANON_KEY` → Value: your Supabase anon key
8. Click **Deploy**
9. Wait 1-2 minutes — your site is now live at **goalplot.vercel.app**!

### Connect your domain:
10. In your Vercel project, go to **Settings** → **Domains**
11. Type **goalplot.com** → Click **Add**
12. Vercel will show you DNS records to add
13. Go back to **Namecheap** dashboard:
    - Click **Domain List** → Click **Manage** next to goalplot.com
    - Click **Advanced DNS**
    - Delete any existing records
    - Add the records Vercel tells you (usually):
      - Type: **A** → Host: **@** → Value: **76.76.21.21**
      - Type: **CNAME** → Host: **www** → Value: **cname.vercel-dns.com**
14. Wait 10-30 minutes for DNS to propagate
15. Your site is now live at **goalplot.com**!

---

## STEP 5: Set Up Cloudflare (10 minutes)

1. Go to **https://www.cloudflare.com**
2. Sign up for free
3. Click **Add a site** → Enter **goalplot.com**
4. Select the **Free plan**
5. Cloudflare will scan your DNS records
6. It will give you new nameservers (like: anna.ns.cloudflare.com)
7. Go to **Namecheap** → Your domain → **Nameservers**
8. Change from **Namecheap Default** to **Custom DNS**
9. Enter the two Cloudflare nameservers
10. Save → Wait up to 24 hours (usually much faster)

### Recommended Cloudflare settings:
11. In Cloudflare dashboard:
    - **SSL/TLS** → Set to **Full (strict)**
    - **Security** → Security Level: **Medium**
    - **Speed** → Enable **Auto Minify** (JavaScript, CSS, HTML)
    - **Caching** → Caching Level: **Standard**

---

## STEP 6: Set Up Paystack for Payments (15 minutes)

1. Go to **https://paystack.com**
2. Click **Create Free Account**
3. Fill in your business details:
   - Business name: GoalPlot (or your registered company name)
   - Business type: Starter Business (or appropriate)
   - What do you do: Online prediction platform
4. Complete email verification
5. In your Paystack dashboard:
   - Go to **Settings** → **API Keys & Webhooks**
   - Copy your **Test Secret Key** (starts with sk_test_)
   - Copy your **Test Public Key** (starts with pk_test_)
   - Save these — you'll add them to Vercel environment variables
6. **For live payments:** Complete Paystack's KYC verification:
   - Upload ID document
   - Add bank account for receiving payments
   - Once approved, you'll get **Live** keys

### Add Paystack keys to Vercel:
7. Go to Vercel → Your project → **Settings** → **Environment Variables**
8. Add:
   - `REACT_APP_PAYSTACK_PUBLIC_KEY` → your Paystack public key
9. Redeploy your project (Vercel → Deployments → Redeploy)

---

## STEP 7: Set Up Email Collection (10 minutes)

### Option A: Mailchimp (Recommended)
1. Go to **https://mailchimp.com**
2. Sign up for the Free plan
3. Create an **Audience** called "GoalPlot Users"
4. Get your signup form embed code or API key
5. Anyone who signs up on your site gets added to this list

### Option B: Just use Supabase
Your database already stores emails from registered users. You can export them anytime from the Supabase dashboard → Table Editor → profiles → Export as CSV.

---

## STEP 8: Social Media Accounts (30 minutes)

Create accounts with the handle **@goalplot** on:

1. **Instagram** → instagram.com (create a Business account)
2. **Twitter/X** → x.com
3. **TikTok** → tiktok.com
4. **Facebook** → Create a Page at facebook.com/pages/create
5. **WhatsApp Business** → Download the app, register with a business phone number
6. **YouTube** → Create a channel at youtube.com

Use the social media content pack (Deliverable 7) for your first posts.

---

## STEP 9: Set Up Paystack Payment Page (Quick Alternative)

If you want payments working TODAY without coding:

1. In your Paystack dashboard, go to **Payment Pages**
2. Click **Create New Page**
3. Create two pages:
   - **Golden Boot Upgrade — $9.99**
   - **World Champion Upgrade — $24.99**
4. Each page gives you a payment link like: https://paystack.com/pay/goalplot-golden
5. Add these links to your website's pricing buttons

This gets you accepting payments TODAY with zero code.

---

## STEP 10: Go Live Checklist

Before you share GoalPlot with the world:

- [ ] Domain registered and pointing to Vercel
- [ ] Site loads at goalplot.com with HTTPS
- [ ] Cloudflare active (check for orange cloud icon)
- [ ] Supabase database created with all tables
- [ ] User registration works (test it yourself)
- [ ] At least 6 matches loaded in the database
- [ ] Paystack payment pages created
- [ ] Social media accounts created
- [ ] First social media post published
- [ ] Terms & Conditions page accessible on the site
- [ ] Privacy Policy page accessible on the site
- [ ] Your land documents scanned and ready to display

---

## HOW TO UPDATE YOUR SITE

Every time Claude gives you updated code:

1. Go to GitHub → Your goalplot repository
2. Click **Add file** → **Upload files** (or edit existing files)
3. Upload/replace the files
4. Commit the changes
5. Vercel automatically detects the change and redeploys (takes ~60 seconds)
6. Your live site updates automatically

---

## HOW TO MANAGE YOUR PLATFORM DAILY

### View users:
Supabase → Table Editor → profiles

### View predictions:
Supabase → Table Editor → predictions

### Enter match results (IMPORTANT — do this after each match):
Supabase → Table Editor → matches → Find the match → Edit:
- Set home_score and away_score
- Set is_completed to TRUE
- Then go to SQL Editor and run:
```
SELECT public.score_match(MATCH_ID_HERE);
```
Replace MATCH_ID_HERE with the match ID number. This auto-calculates all points.

### View leaderboard:
Supabase → SQL Editor → Run:
```
SELECT * FROM public.get_leaderboard(100);
```

### View revenue:
Paystack dashboard → Transactions

### Suspend a cheater:
Supabase → Table Editor → profiles → Find user → Set is_suspended to TRUE

### Export email list:
Supabase → Table Editor → profiles → Click export icon → CSV

---

## WHEN YOU OUTGROW FREE TIERS

| Service | Free Limit | Paid Upgrade |
|---------|-----------|-------------|
| Supabase | 50,000 rows, 500MB storage | $25/month (Pro) |
| Vercel | 100GB bandwidth | $20/month (Pro) |
| Cloudflare | Unlimited on free | $20/month (Pro) for more features |

You likely won't hit these limits until 30,000+ active users. By then, your VIP revenue should easily cover the costs.

---

## EMERGENCY CONTACTS

If something breaks:
- **Supabase issues:** https://supabase.com/docs or their Discord
- **Vercel issues:** https://vercel.com/docs
- **Cloudflare issues:** https://developers.cloudflare.com
- **Paystack issues:** https://paystack.com/docs or support@paystack.co
- **Come back to Claude:** Paste the error message and I'll help fix it

---

*You're building this with the same tools that companies raising millions of dollars use. The only difference is you're getting it for free. Ship it.*
