-- ============================================
-- GOALPLOT DATABASE SCHEMA
-- Paste this entire file into Supabase SQL Editor
-- Go to: supabase.com > Your Project > SQL Editor > New Query > Paste > Run
-- ============================================

-- 1. USERS PROFILE (extends Supabase auth)
CREATE TABLE public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  country TEXT DEFAULT '',
  tier TEXT DEFAULT 'free' CHECK (tier IN ('free', 'golden_boot', 'champion')),
  points INTEGER DEFAULT 0,
  referral_code TEXT UNIQUE,
  referred_by UUID REFERENCES public.profiles(id),
  referral_count INTEGER DEFAULT 0,
  is_flagged BOOLEAN DEFAULT false,
  is_suspended BOOLEAN DEFAULT false,
  is_admin BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. MATCHES
CREATE TABLE public.matches (
  id SERIAL PRIMARY KEY,
  home_team TEXT NOT NULL,
  away_team TEXT NOT NULL,
  home_code TEXT NOT NULL,
  away_code TEXT NOT NULL,
  group_name TEXT,
  match_phase TEXT DEFAULT 'group' CHECK (match_phase IN ('group', 'round_of_32', 'round_of_16', 'quarter', 'semi', 'third_place', 'final')),
  stadium TEXT,
  match_date TIMESTAMPTZ NOT NULL,
  home_score INTEGER,
  away_score INTEGER,
  is_completed BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. PREDICTIONS
CREATE TABLE public.predictions (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  match_id INTEGER REFERENCES public.matches(id) ON DELETE CASCADE NOT NULL,
  predicted_winner TEXT NOT NULL CHECK (predicted_winner IN ('home', 'away', 'draw')),
  predicted_home_score INTEGER, -- VIP only
  predicted_away_score INTEGER, -- VIP only
  points_earned INTEGER DEFAULT 0,
  is_correct BOOLEAN,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, match_id) -- one prediction per match per user
);

-- 4. GROUP PREDICTIONS
CREATE TABLE public.group_predictions (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  group_name TEXT NOT NULL,
  predicted_winner TEXT NOT NULL,
  points_earned INTEGER DEFAULT 0,
  is_correct BOOLEAN,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, group_name)
);

-- 5. TOURNAMENT WINNER PREDICTION
CREATE TABLE public.tournament_predictions (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  predicted_winner TEXT NOT NULL,
  points_earned INTEGER DEFAULT 0,
  is_correct BOOLEAN,
  is_locked BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- 6. PAYMENTS
CREATE TABLE public.payments (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  payment_method TEXT NOT NULL,
  payment_reference TEXT UNIQUE NOT NULL,
  tier_purchased TEXT NOT NULL CHECK (tier_purchased IN ('golden_boot', 'champion')),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. REFERRALS TRACKING
CREATE TABLE public.referrals (
  id SERIAL PRIMARY KEY,
  referrer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  referred_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  points_awarded BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(referred_id) -- each user can only be referred once
);

-- 8. SECURITY LOG
CREATE TABLE public.security_logs (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id),
  event_type TEXT NOT NULL,
  ip_address TEXT,
  details TEXT,
  severity TEXT DEFAULT 'info' CHECK (severity IN ('info', 'low', 'medium', 'high', 'critical')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES (for fast queries)
-- ============================================
CREATE INDEX idx_profiles_points ON public.profiles(points DESC);
CREATE INDEX idx_profiles_referral_code ON public.profiles(referral_code);
CREATE INDEX idx_profiles_tier ON public.profiles(tier);
CREATE INDEX idx_predictions_user ON public.predictions(user_id);
CREATE INDEX idx_predictions_match ON public.predictions(match_id);
CREATE INDEX idx_matches_date ON public.matches(match_date);
CREATE INDEX idx_payments_user ON public.payments(user_id);
CREATE INDEX idx_security_logs_created ON public.security_logs(created_at DESC);

-- ============================================
-- ROW LEVEL SECURITY (RLS) - Critical for security
-- ============================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tournament_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security_logs ENABLE ROW LEVEL SECURITY;

-- PROFILES: Users can read all profiles (for leaderboard), update only their own
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- PREDICTIONS: Users can CRUD their own, read others for leaderboard
CREATE POLICY "Users can view all predictions" ON public.predictions FOR SELECT USING (true);
CREATE POLICY "Users can insert own predictions" ON public.predictions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own predictions" ON public.predictions FOR UPDATE USING (auth.uid() = user_id);

-- GROUP PREDICTIONS: Same as above
CREATE POLICY "Users can view all group predictions" ON public.group_predictions FOR SELECT USING (true);
CREATE POLICY "Users can insert own group predictions" ON public.group_predictions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own group predictions" ON public.group_predictions FOR UPDATE USING (auth.uid() = user_id);

-- TOURNAMENT PREDICTIONS: Same
CREATE POLICY "Users can view all tournament predictions" ON public.tournament_predictions FOR SELECT USING (true);
CREATE POLICY "Users can insert own tournament prediction" ON public.tournament_predictions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own tournament prediction" ON public.tournament_predictions FOR UPDATE USING (auth.uid() = user_id);

-- MATCHES: Everyone can read, only admins can modify (via Supabase dashboard)
CREATE POLICY "Everyone can view matches" ON public.matches FOR SELECT USING (true);

-- PAYMENTS: Users can only see their own payments
CREATE POLICY "Users can view own payments" ON public.payments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own payments" ON public.payments FOR INSERT WITH CHECK (auth.uid() = user_id);

-- REFERRALS: Users can see their own referrals
CREATE POLICY "Users can view own referrals" ON public.referrals FOR SELECT USING (auth.uid() = referrer_id);

-- SECURITY LOGS: Only readable via Supabase dashboard (no public access)
CREATE POLICY "No public access to security logs" ON public.security_logs FOR SELECT USING (false);

-- ============================================
-- FUNCTIONS
-- ============================================

-- Auto-create profile when user signs up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, username, email, referral_code)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    NEW.email,
    LOWER(SUBSTRING(MD5(NEW.id::text) FROM 1 FOR 8))
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to auto-create profile
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to get leaderboard
CREATE OR REPLACE FUNCTION public.get_leaderboard(limit_count INTEGER DEFAULT 100)
RETURNS TABLE (
  rank BIGINT,
  user_id UUID,
  username TEXT,
  country TEXT,
  tier TEXT,
  points INTEGER,
  prediction_count BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    ROW_NUMBER() OVER (ORDER BY p.points DESC, p.created_at ASC) as rank,
    p.id as user_id,
    p.username,
    p.country,
    p.tier,
    p.points,
    (SELECT COUNT(*) FROM public.predictions pred WHERE pred.user_id = p.id) as prediction_count
  FROM public.profiles p
  WHERE p.is_suspended = false
  ORDER BY p.points DESC, p.created_at ASC
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql;

-- Function to calculate points after match result is entered
CREATE OR REPLACE FUNCTION public.score_match(p_match_id INTEGER)
RETURNS VOID AS $$
DECLARE
  v_match RECORD;
  v_prediction RECORD;
  v_actual_winner TEXT;
  v_points INTEGER;
  v_multiplier INTEGER;
BEGIN
  -- Get match result
  SELECT * INTO v_match FROM public.matches WHERE id = p_match_id AND is_completed = true;
  IF NOT FOUND THEN RETURN; END IF;

  -- Determine actual winner
  IF v_match.home_score > v_match.away_score THEN v_actual_winner := 'home';
  ELSIF v_match.away_score > v_match.home_score THEN v_actual_winner := 'away';
  ELSE v_actual_winner := 'draw';
  END IF;

  -- Score each prediction for this match
  FOR v_prediction IN SELECT pred.*, prof.tier FROM public.predictions pred JOIN public.profiles prof ON pred.user_id = prof.id WHERE pred.match_id = p_match_id
  LOOP
    v_points := 0;

    -- Correct winner prediction = 10 points
    IF v_prediction.predicted_winner = v_actual_winner THEN
      v_points := 10;

      -- Exact score prediction (VIP) = 30 points
      IF v_prediction.predicted_home_score = v_match.home_score
         AND v_prediction.predicted_away_score = v_match.away_score THEN
        v_points := 30;
      END IF;
    END IF;

    -- Apply tier multiplier
    v_multiplier := 1;
    IF v_prediction.tier = 'golden_boot' THEN v_multiplier := 2;
    ELSIF v_prediction.tier = 'champion' THEN v_multiplier := 5;
    END IF;

    v_points := v_points * v_multiplier;

    -- Update prediction
    UPDATE public.predictions
    SET points_earned = v_points, is_correct = (v_prediction.predicted_winner = v_actual_winner)
    WHERE id = v_prediction.id;

    -- Update user total points
    UPDATE public.profiles
    SET points = points + v_points, updated_at = NOW()
    WHERE id = v_prediction.user_id;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- SEED DATA: World Cup 2026 Group Stage Matches
-- ============================================

-- GROUP A
INSERT INTO public.matches (home_team, away_team, home_code, away_code, group_name, stadium, match_date) VALUES
('USA', 'Morocco', '🇺🇸', '🇲🇦', 'A', 'SoFi Stadium, Los Angeles', '2026-06-11 20:00:00+00'),
('Mexico', 'Jamaica', '🇲🇽', '🇯🇲', 'A', 'Estadio Azteca, Mexico City', '2026-06-12 18:00:00+00'),
('USA', 'Jamaica', '🇺🇸', '🇯🇲', 'A', 'SoFi Stadium, Los Angeles', '2026-06-16 20:00:00+00'),
('Morocco', 'Mexico', '🇲🇦', '🇲🇽', 'A', 'Estadio Azteca, Mexico City', '2026-06-16 18:00:00+00'),
('USA', 'Mexico', '🇺🇸', '🇲🇽', 'A', 'SoFi Stadium, Los Angeles', '2026-06-20 20:00:00+00'),
('Morocco', 'Jamaica', '🇲🇦', '🇯🇲', 'A', 'Rose Bowl, Los Angeles', '2026-06-20 20:00:00+00');

-- GROUP C (Argentina)
INSERT INTO public.matches (home_team, away_team, home_code, away_code, group_name, stadium, match_date) VALUES
('Argentina', 'Egypt', '🇦🇷', '🇪🇬', 'C', 'Hard Rock Stadium, Miami', '2026-06-12 21:00:00+00'),
('Uzbekistan', 'Indonesia', '🇺🇿', '🇮🇩', 'C', 'Inter&Co Stadium, Orlando', '2026-06-12 15:00:00+00'),
('Argentina', 'Indonesia', '🇦🇷', '🇮🇩', 'C', 'Hard Rock Stadium, Miami', '2026-06-17 21:00:00+00'),
('Egypt', 'Uzbekistan', '🇪🇬', '🇺🇿', 'C', 'Inter&Co Stadium, Orlando', '2026-06-17 15:00:00+00');

-- GROUP E (Brazil / Nigeria)
INSERT INTO public.matches (home_team, away_team, home_code, away_code, group_name, stadium, match_date) VALUES
('Brazil', 'Nigeria', '🇧🇷', '🇳🇬', 'E', 'Rose Bowl, Los Angeles', '2026-06-13 21:00:00+00'),
('Australia', 'Turkey', '🇦🇺', '🇹🇷', 'E', 'BC Place, Vancouver', '2026-06-13 15:00:00+00'),
('Brazil', 'Turkey', '🇧🇷', '🇹🇷', 'E', 'Rose Bowl, Los Angeles', '2026-06-18 21:00:00+00'),
('Nigeria', 'Australia', '🇳🇬', '🇦🇺', 'E', 'BC Place, Vancouver', '2026-06-18 15:00:00+00');

-- GROUP D (France)
INSERT INTO public.matches (home_team, away_team, home_code, away_code, group_name, stadium, match_date) VALUES
('France', 'Colombia', '🇫🇷', '🇨🇴', 'D', 'AT&T Stadium, Dallas', '2026-06-13 20:00:00+00'),
('New Zealand', 'Bahrain', '🇳🇿', '🇧🇭', 'D', 'NRG Stadium, Houston', '2026-06-13 14:00:00+00');

-- GROUP H (England)
INSERT INTO public.matches (home_team, away_team, home_code, away_code, group_name, stadium, match_date) VALUES
('England', 'Chile', '🇬🇧', '🇨🇱', 'H', 'MetLife Stadium, New York', '2026-06-14 17:00:00+00'),
('Senegal', 'Albania', '🇸🇳', '🇦🇱', 'H', 'Lincoln Financial Field, Philadelphia', '2026-06-14 14:00:00+00');

-- ============================================
-- DONE! Your database is ready.
-- ============================================
