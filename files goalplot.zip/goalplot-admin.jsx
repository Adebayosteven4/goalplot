import { useState } from "react";

const STATS = {
  users: 48320, vip: 6240, revenue: 89450, predictions: 312800,
  today_signups: 842, today_predictions: 12450, active_now: 1834, conversion: 12.9,
};

const USERS = [
  { id: 1, name: "AdemolaKing", email: "ademola@email.com", country: "🇳🇬 Nigeria", tier: "Champion", pts: 2450, preds: 87, joined: "2026-04-12", status: "active", flagged: false },
  { id: 2, name: "SambaFan99", email: "samba99@email.com", country: "🇧🇷 Brazil", tier: "Golden Boot", pts: 2380, preds: 82, joined: "2026-04-14", status: "active", flagged: false },
  { id: 3, name: "GoalMachine", email: "goalmachine@email.com", country: "🇬🇧 UK", tier: "Free", pts: 2310, preds: 79, joined: "2026-04-15", status: "active", flagged: false },
  { id: 4, name: "FutbolGuru", email: "futbolguru@email.com", country: "🇪🇸 Spain", tier: "Golden Boot", pts: 2250, preds: 74, joined: "2026-04-18", status: "active", flagged: false },
  { id: 5, name: "SusBot001", email: "notabot@tempmail.com", country: "🇷🇺 Russia", tier: "Free", pts: 1200, preds: 420, joined: "2026-05-28", status: "flagged", flagged: true },
  { id: 6, name: "ThreeStars", email: "three@email.com", country: "🇦🇷 Argentina", tier: "Champion", pts: 2180, preds: 71, joined: "2026-04-20", status: "active", flagged: false },
  { id: 7, name: "CheaterX", email: "multi@proxy.com", country: "🇺🇸 USA", tier: "Free", pts: 980, preds: 310, joined: "2026-05-30", status: "suspended", flagged: true },
  { id: 8, name: "OranjeArmy", email: "oranje@email.com", country: "🇳🇱 Netherlands", tier: "Golden Boot", pts: 2100, preds: 68, joined: "2026-04-22", status: "active", flagged: false },
];

const REVENUE = [
  { month: "Apr", free: 12400, golden: 3200, champion: 890, revenue: 42850 },
  { month: "May", free: 22100, golden: 2400, champion: 620, revenue: 31200 },
  { month: "Jun", free: 13820, golden: 640, champion: 130, revenue: 15400 },
];

const SECURITY_LOG = [
  { time: "2 min ago", event: "Failed login (5x)", user: "unknown", ip: "103.45.xx.xx", severity: "high" },
  { time: "8 min ago", event: "Rate limit triggered", user: "SusBot001", ip: "91.23.xx.xx", severity: "medium" },
  { time: "15 min ago", event: "Multiple account detected", user: "CheaterX", ip: "72.14.xx.xx", severity: "high" },
  { time: "1 hr ago", event: "VIP payment successful", user: "OranjeArmy", ip: "45.67.xx.xx", severity: "info" },
  { time: "1 hr ago", event: "Password reset requested", user: "ThreeStars", ip: "181.22.xx.xx", severity: "low" },
  { time: "2 hrs ago", event: "Admin login", user: "admin@goalplot", ip: "10.0.xx.xx", severity: "info" },
  { time: "3 hrs ago", event: "Suspicious prediction pattern", user: "SusBot001", ip: "91.23.xx.xx", severity: "high" },
  { time: "5 hrs ago", event: "New VIP signup", user: "FutbolGuru", ip: "83.12.xx.xx", severity: "info" },
];

const COUNTRIES_DATA = [
  { country: "🇳🇬 Nigeria", users: 14200, pct: 29.4 },
  { country: "🇬🇧 UK", users: 6100, pct: 12.6 },
  { country: "🇺🇸 USA", users: 5800, pct: 12.0 },
  { country: "🇧🇷 Brazil", users: 4200, pct: 8.7 },
  { country: "🇮🇳 India", users: 3100, pct: 6.4 },
  { country: "🇩🇪 Germany", users: 2400, pct: 5.0 },
  { country: "🇫🇷 France", users: 2100, pct: 4.3 },
  { country: "🇪🇸 Spain", users: 1800, pct: 3.7 },
  { country: "🇿🇦 South Africa", users: 1600, pct: 3.3 },
  { country: "Other", users: 7020, pct: 14.5 },
];

export default function AdminDashboard() {
  const [tab, setTab] = useState("overview");
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [userFilter, setUserFilter] = useState("all");

  const filteredUsers = USERS.filter((u) => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase());
    if (userFilter === "flagged") return matchSearch && u.flagged;
    if (userFilter === "vip") return matchSearch && u.tier !== "Free";
    if (userFilter === "suspended") return matchSearch && u.status === "suspended";
    return matchSearch;
  });

  const tabs = [
    { id: "overview", label: "Overview", icon: "📊" },
    { id: "users", label: "Users", icon: "👥" },
    { id: "predictions", label: "Predictions", icon: "🎯" },
    { id: "revenue", label: "Revenue", icon: "💰" },
    { id: "security", label: "Security", icon: "🛡️" },
  ];

  const sevColor = { high: "#E74C4C", medium: "#E6793A", low: "#C9A55A", info: "#3CAC3B" };

  return (
    <div className="ad">
      <style>{CSS}</style>

      {/* SIDEBAR */}
      <aside className="ad-side">
        <div className="ad-side-logo">
          <span style={{ fontSize: 22 }}>🏆</span>
          <div>
            <div className="ad-side-brand">GOALPLOT</div>
            <div className="ad-side-sub">Admin Panel</div>
          </div>
        </div>
        <nav className="ad-side-nav">
          {tabs.map((t) => (
            <button key={t.id} className={`ad-side-link ${tab === t.id ? "active" : ""}`} onClick={() => setTab(t.id)}>
              <span>{t.icon}</span> {t.label}
            </button>
          ))}
        </nav>
        <div className="ad-side-footer">
          <div className="ad-side-user">
            <div className="ad-avatar">A</div>
            <div>
              <div className="ad-side-name">Admin</div>
              <div className="ad-side-role">Super Admin</div>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN */}
      <main className="ad-main">
        {/* TOPBAR */}
        <header className="ad-topbar">
          <h1 className="ad-topbar-title">{tabs.find((t) => t.id === tab)?.icon} {tabs.find((t) => t.id === tab)?.label}</h1>
          <div className="ad-topbar-right">
            <div className="ad-live-dot" />
            <span className="ad-live-text">{STATS.active_now.toLocaleString()} active now</span>
          </div>
        </header>

        {/* ═══ OVERVIEW ═══ */}
        {tab === "overview" && (
          <div className="ad-content">
            {/* STAT CARDS */}
            <div className="ad-stats-grid">
              {[
                { label: "Total Users", value: STATS.users.toLocaleString(), change: "+842 today", icon: "👥", color: "#1B9ED3" },
                { label: "VIP Members", value: STATS.vip.toLocaleString(), change: `${STATS.conversion}% conversion`, icon: "💎", color: "#C9A55A" },
                { label: "Total Revenue", value: `$${STATS.revenue.toLocaleString()}`, change: "+$2,400 today", icon: "💰", color: "#3CAC3B" },
                { label: "Predictions Made", value: STATS.predictions.toLocaleString(), change: "+12,450 today", icon: "🎯", color: "#E6793A" },
              ].map((s) => (
                <div key={s.label} className="ad-stat-card">
                  <div className="ad-stat-header">
                    <span className="ad-stat-icon" style={{ background: `${s.color}15`, color: s.color }}>{s.icon}</span>
                    <span className="ad-stat-label">{s.label}</span>
                  </div>
                  <div className="ad-stat-value">{s.value}</div>
                  <div className="ad-stat-change">{s.change}</div>
                </div>
              ))}
            </div>

            {/* CHARTS ROW */}
            <div className="ad-row">
              {/* SIGNUPS CHART */}
              <div className="ad-card flex2">
                <h3 className="ad-card-title">Signups by Month</h3>
                <div className="ad-bar-chart">
                  {REVENUE.map((r) => (
                    <div key={r.month} className="ad-bar-col">
                      <div className="ad-bar-stack">
                        <div className="ad-bar champion" style={{ height: `${(r.champion / 1000) * 6}px` }} title={`Champion: ${r.champion}`} />
                        <div className="ad-bar golden" style={{ height: `${(r.golden / 1000) * 6}px` }} title={`Golden Boot: ${r.golden}`} />
                        <div className="ad-bar free" style={{ height: `${(r.free / 1000) * 3}px` }} title={`Free: ${r.free}`} />
                      </div>
                      <div className="ad-bar-label">{r.month}</div>
                    </div>
                  ))}
                </div>
                <div className="ad-legend">
                  <span><i style={{ background: "#1B9ED3" }} /> Free</span>
                  <span><i style={{ background: "#C9A55A" }} /> Golden Boot</span>
                  <span><i style={{ background: "#E74C4C" }} /> Champion</span>
                </div>
              </div>

              {/* TOP COUNTRIES */}
              <div className="ad-card flex1">
                <h3 className="ad-card-title">Top Countries</h3>
                <div className="ad-countries">
                  {COUNTRIES_DATA.slice(0, 7).map((c) => (
                    <div key={c.country} className="ad-country-row">
                      <span className="ad-country-name">{c.country}</span>
                      <div className="ad-country-bar-bg">
                        <div className="ad-country-bar" style={{ width: `${(c.pct / 30) * 100}%` }} />
                      </div>
                      <span className="ad-country-pct">{c.pct}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* RECENT SECURITY */}
            <div className="ad-card">
              <h3 className="ad-card-title">🛡️ Recent Security Events</h3>
              <div className="ad-log-list">
                {SECURITY_LOG.slice(0, 5).map((l, i) => (
                  <div key={i} className="ad-log-row">
                    <span className="ad-sev" style={{ background: sevColor[l.severity] }} />
                    <span className="ad-log-time">{l.time}</span>
                    <span className="ad-log-event">{l.event}</span>
                    <span className="ad-log-user">{l.user}</span>
                    <span className="ad-log-ip">{l.ip}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ═══ USERS ═══ */}
        {tab === "users" && (
          <div className="ad-content">
            <div className="ad-toolbar">
              <input className="ad-search" placeholder="Search users by name or email..." value={search} onChange={(e) => setSearch(e.target.value)} />
              <div className="ad-filters">
                {[
                  { id: "all", label: "All" },
                  { id: "vip", label: "VIP" },
                  { id: "flagged", label: "⚠️ Flagged" },
                  { id: "suspended", label: "🚫 Suspended" },
                ].map((f) => (
                  <button key={f.id} className={`ad-filter-btn ${userFilter === f.id ? "active" : ""}`} onClick={() => setUserFilter(f.id)}>
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="ad-card">
              <div className="ad-table">
                <div className="ad-table-header">
                  <span style={{ width: 40 }}>#</span>
                  <span style={{ flex: 1 }}>User</span>
                  <span style={{ width: 120 }}>Country</span>
                  <span style={{ width: 100 }}>Tier</span>
                  <span style={{ width: 70, textAlign: "right" }}>Points</span>
                  <span style={{ width: 70, textAlign: "right" }}>Preds</span>
                  <span style={{ width: 90 }}>Status</span>
                  <span style={{ width: 100 }}>Actions</span>
                </div>
                {filteredUsers.map((u) => (
                  <div key={u.id} className={`ad-table-row ${u.flagged ? "flagged" : ""}`}>
                    <span style={{ width: 40, color: "#556" }}>{u.id}</span>
                    <span style={{ flex: 1 }}>
                      <div className="ad-user-cell">
                        <div className="ad-user-name">{u.name}</div>
                        <div className="ad-user-email">{u.email}</div>
                      </div>
                    </span>
                    <span style={{ width: 120, fontSize: 13 }}>{u.country}</span>
                    <span style={{ width: 100 }}>
                      <span className={`ad-tier-badge ${u.tier === "Champion" ? "champ" : u.tier === "Golden Boot" ? "gold" : "free"}`}>
                        {u.tier}
                      </span>
                    </span>
                    <span style={{ width: 70, textAlign: "right", fontWeight: 700, color: "#C9A55A" }}>{u.pts.toLocaleString()}</span>
                    <span style={{ width: 70, textAlign: "right", color: "#889" }}>{u.preds}</span>
                    <span style={{ width: 90 }}>
                      <span className={`ad-status ${u.status}`}>
                        {u.status === "active" ? "✓ Active" : u.status === "flagged" ? "⚠ Flagged" : "🚫 Suspended"}
                      </span>
                    </span>
                    <span style={{ width: 100, display: "flex", gap: 4 }}>
                      <button className="ad-action-btn" title="View" onClick={() => setSelectedUser(u)}>👁</button>
                      <button className="ad-action-btn warn" title="Flag">⚠</button>
                      <button className="ad-action-btn danger" title="Suspend">🚫</button>
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* USER DETAIL MODAL */}
            {selectedUser && (
              <div className="ad-overlay" onClick={() => setSelectedUser(null)}>
                <div className="ad-modal" onClick={(e) => e.stopPropagation()}>
                  <button className="ad-modal-close" onClick={() => setSelectedUser(null)}>✕</button>
                  <h3 className="ad-modal-title">User Details</h3>
                  <div className="ad-detail-grid">
                    {[
                      ["Username", selectedUser.name],
                      ["Email", selectedUser.email],
                      ["Country", selectedUser.country],
                      ["Tier", selectedUser.tier],
                      ["Points", selectedUser.pts.toLocaleString()],
                      ["Predictions", selectedUser.preds],
                      ["Joined", selectedUser.joined],
                      ["Status", selectedUser.status],
                    ].map(([k, v]) => (
                      <div key={k} className="ad-detail-item">
                        <div className="ad-detail-label">{k}</div>
                        <div className="ad-detail-value">{v}</div>
                      </div>
                    ))}
                  </div>
                  <div className="ad-modal-actions">
                    <button className="ad-btn gold">Reset Password</button>
                    <button className="ad-btn outline">Export Data</button>
                    <button className="ad-btn danger">Suspend Account</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ═══ PREDICTIONS ═══ */}
        {tab === "predictions" && (
          <div className="ad-content">
            <div className="ad-stats-grid">
              {[
                { label: "Total Predictions", value: "312,800", icon: "🎯" },
                { label: "Matches Predicted", value: "6 / 104", icon: "⚽" },
                { label: "Avg Predictions / User", value: "6.5", icon: "📊" },
                { label: "Most Picked Winner", value: "🇦🇷 Argentina", icon: "🏆" },
              ].map((s) => (
                <div key={s.label} className="ad-stat-card">
                  <div className="ad-stat-header"><span className="ad-stat-icon">{s.icon}</span><span className="ad-stat-label">{s.label}</span></div>
                  <div className="ad-stat-value">{s.value}</div>
                </div>
              ))}
            </div>

            <div className="ad-card">
              <h3 className="ad-card-title">Tournament Winner Predictions Distribution</h3>
              <div className="ad-pred-dist">
                {[
                  { team: "🇦🇷 Argentina", pct: 22.4 },
                  { team: "🇫🇷 France", pct: 18.1 },
                  { team: "🇧🇷 Brazil", pct: 15.7 },
                  { team: "🇬🇧 England", pct: 12.3 },
                  { team: "🇪🇸 Spain", pct: 9.8 },
                  { team: "🇩🇪 Germany", pct: 7.2 },
                  { team: "🇵🇹 Portugal", pct: 5.1 },
                  { team: "🇳🇱 Netherlands", pct: 3.4 },
                  { team: "Others", pct: 6.0 },
                ].map((t) => (
                  <div key={t.team} className="ad-pred-row">
                    <span className="ad-pred-team">{t.team}</span>
                    <div className="ad-pred-bar-bg">
                      <div className="ad-pred-bar" style={{ width: `${(t.pct / 25) * 100}%` }} />
                    </div>
                    <span className="ad-pred-pct">{t.pct}%</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="ad-card">
              <h3 className="ad-card-title">Group Stage Winner Predictions</h3>
              <div className="ad-group-grid">
                {Object.entries({
                  A: "🇺🇸 USA (64%)", B: "🇵🇹 Portugal (71%)", C: "🇦🇷 Argentina (82%)",
                  D: "🇫🇷 France (76%)", E: "🇧🇷 Brazil (68%)", F: "🇩🇪 Germany (59%)",
                  G: "🇪🇸 Spain (73%)", H: "🇬🇧 England (67%)", I: "🇳🇱 Netherlands (55%)",
                  J: "🇧🇪 Belgium (48%)", K: "🇮🇹 Italy (62%)", L: "🇨🇭 Switzerland (44%)",
                }).map(([g, v]) => (
                  <div key={g} className="ad-group-item">
                    <div className="ad-group-letter">Group {g}</div>
                    <div className="ad-group-pick">{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ═══ REVENUE ═══ */}
        {tab === "revenue" && (
          <div className="ad-content">
            <div className="ad-stats-grid">
              {[
                { label: "Total Revenue", value: "$89,450", change: "+$2,400 today", icon: "💰", color: "#3CAC3B" },
                { label: "Golden Boot Sales", value: "5,240", change: "$52,348", icon: "🥇", color: "#C9A55A" },
                { label: "Champion Sales", value: "1,000", change: "$24,990", icon: "👑", color: "#E74C4C" },
                { label: "Avg Revenue / User", value: "$1.85", change: "VIP: $14.35", icon: "📈", color: "#1B9ED3" },
              ].map((s) => (
                <div key={s.label} className="ad-stat-card">
                  <div className="ad-stat-header">
                    <span className="ad-stat-icon" style={{ background: `${s.color}15`, color: s.color }}>{s.icon}</span>
                    <span className="ad-stat-label">{s.label}</span>
                  </div>
                  <div className="ad-stat-value">{s.value}</div>
                  <div className="ad-stat-change">{s.change}</div>
                </div>
              ))}
            </div>

            <div className="ad-card">
              <h3 className="ad-card-title">Revenue by Month</h3>
              <div className="ad-revenue-table">
                <div className="ad-table-header">
                  <span style={{ flex: 1 }}>Month</span>
                  <span style={{ width: 100, textAlign: "right" }}>Free Signups</span>
                  <span style={{ width: 100, textAlign: "right" }}>Golden Boot</span>
                  <span style={{ width: 100, textAlign: "right" }}>Champion</span>
                  <span style={{ width: 110, textAlign: "right" }}>Revenue</span>
                </div>
                {REVENUE.map((r) => (
                  <div key={r.month} className="ad-table-row">
                    <span style={{ flex: 1, fontWeight: 700, color: "#fff" }}>{r.month} 2026</span>
                    <span style={{ width: 100, textAlign: "right" }}>{r.free.toLocaleString()}</span>
                    <span style={{ width: 100, textAlign: "right", color: "#C9A55A" }}>{r.golden.toLocaleString()}</span>
                    <span style={{ width: 100, textAlign: "right", color: "#E74C4C" }}>{r.champion.toLocaleString()}</span>
                    <span style={{ width: 110, textAlign: "right", fontWeight: 700, color: "#3CAC3B" }}>${r.revenue.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="ad-card">
              <h3 className="ad-card-title">Payment Method Breakdown</h3>
              <div className="ad-pay-grid">
                {[
                  { method: "💳 Stripe", amount: "$38,200", pct: 42.7 },
                  { method: "🅿️ PayPal", amount: "$18,900", pct: 21.1 },
                  { method: "🏦 Paystack", amount: "$14,500", pct: 16.2 },
                  { method: "🦋 Flutterwave", amount: "$9,800", pct: 11.0 },
                  { method: "₿ Crypto", amount: "$5,100", pct: 5.7 },
                  { method: "📲 M-Pesa", amount: "$2,950", pct: 3.3 },
                ].map((p) => (
                  <div key={p.method} className="ad-pay-row">
                    <span className="ad-pay-method">{p.method}</span>
                    <div className="ad-pred-bar-bg"><div className="ad-pred-bar green" style={{ width: `${(p.pct / 45) * 100}%` }} /></div>
                    <span className="ad-pay-amount">{p.amount}</span>
                    <span className="ad-pay-pct">{p.pct}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ═══ SECURITY ═══ */}
        {tab === "security" && (
          <div className="ad-content">
            <div className="ad-stats-grid">
              {[
                { label: "Blocked Attacks (24h)", value: "1,247", icon: "🛡️", color: "#E74C4C" },
                { label: "Flagged Accounts", value: "23", icon: "⚠️", color: "#E6793A" },
                { label: "Suspended Accounts", value: "8", icon: "🚫", color: "#C9A55A" },
                { label: "Uptime (30d)", value: "99.97%", icon: "✅", color: "#3CAC3B" },
              ].map((s) => (
                <div key={s.label} className="ad-stat-card">
                  <div className="ad-stat-header">
                    <span className="ad-stat-icon" style={{ background: `${s.color}15`, color: s.color }}>{s.icon}</span>
                    <span className="ad-stat-label">{s.label}</span>
                  </div>
                  <div className="ad-stat-value">{s.value}</div>
                </div>
              ))}
            </div>

            <div className="ad-card">
              <h3 className="ad-card-title">Security Event Log</h3>
              <div className="ad-log-list">
                {SECURITY_LOG.map((l, i) => (
                  <div key={i} className="ad-log-row">
                    <span className="ad-sev" style={{ background: sevColor[l.severity] }} />
                    <span className="ad-log-time">{l.time}</span>
                    <span className="ad-log-event">{l.event}</span>
                    <span className="ad-log-user">{l.user}</span>
                    <span className="ad-log-ip">{l.ip}</span>
                    <span className={`ad-sev-tag ${l.severity}`}>{l.severity.toUpperCase()}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="ad-row">
              <div className="ad-card flex1">
                <h3 className="ad-card-title">Threat Types (24h)</h3>
                <div className="ad-threat-list">
                  {[
                    { type: "Brute force login", count: 847, color: "#E74C4C" },
                    { type: "Bot detection", count: 234, color: "#E6793A" },
                    { type: "Multi-account", count: 89, color: "#C9A55A" },
                    { type: "Suspicious predictions", count: 45, color: "#1B9ED3" },
                    { type: "XSS attempts", count: 32, color: "#E74C4C" },
                  ].map((t) => (
                    <div key={t.type} className="ad-threat-row">
                      <span className="ad-threat-dot" style={{ background: t.color }} />
                      <span className="ad-threat-type">{t.type}</span>
                      <span className="ad-threat-count">{t.count}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="ad-card flex1">
                <h3 className="ad-card-title">Quick Actions</h3>
                <div className="ad-quick-actions">
                  <button className="ad-btn outline full">🔍 Run Security Scan</button>
                  <button className="ad-btn outline full">📊 Export Security Report</button>
                  <button className="ad-btn outline full">🚫 Block IP Range</button>
                  <button className="ad-btn outline full">📧 Send Security Alert</button>
                  <button className="ad-btn danger full">⚠️ Emergency: Lock All Accounts</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&family=Noto+Sans:wght@300;400;500;600;700&display=swap');
* { box-sizing: border-box; margin: 0; padding: 0; }
.ad { display: flex; min-height: 100vh; font-family: 'Noto Sans', sans-serif; background: #080B12; color: #C0C8D4; }

/* SIDEBAR */
.ad-side { width: 220px; background: #0C1019; border-right: 1px solid rgba(255,255,255,0.05); display: flex; flex-direction: column; position: sticky; top: 0; height: 100vh; flex-shrink: 0; }
.ad-side-logo { display: flex; align-items: center; gap: 10px; padding: 20px 18px; border-bottom: 1px solid rgba(255,255,255,0.05); }
.ad-side-brand { font-family: 'Barlow Condensed', sans-serif; font-weight: 900; font-size: 18px; color: #fff; letter-spacing: 2px; line-height: 1; }
.ad-side-sub { font-size: 10px; color: #C9A55A; font-weight: 700; letter-spacing: 1px; }
.ad-side-nav { flex: 1; padding: 12px 8px; display: flex; flex-direction: column; gap: 2px; }
.ad-side-link { display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: none; border: none; color: #667; font-family: 'Noto Sans', sans-serif; font-size: 13px; font-weight: 600; border-radius: 8px; cursor: pointer; transition: all 0.2s; text-align: left; }
.ad-side-link:hover { background: rgba(255,255,255,0.03); color: #aab; }
.ad-side-link.active { background: rgba(201,165,90,0.08); color: #C9A55A; }
.ad-side-footer { padding: 16px; border-top: 1px solid rgba(255,255,255,0.05); }
.ad-side-user { display: flex; align-items: center; gap: 10px; }
.ad-avatar { width: 32px; height: 32px; border-radius: 8px; background: linear-gradient(135deg, #C9A55A, #8B6F2E); display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; color: #000; }
.ad-side-name { font-size: 13px; font-weight: 700; color: #fff; }
.ad-side-role { font-size: 11px; color: #556; }

/* MAIN */
.ad-main { flex: 1; min-width: 0; }
.ad-topbar { display: flex; align-items: center; justify-content: space-between; padding: 16px 28px; border-bottom: 1px solid rgba(255,255,255,0.05); background: rgba(12,16,25,0.8); backdrop-filter: blur(12px); position: sticky; top: 0; z-index: 10; }
.ad-topbar-title { font-family: 'Barlow Condensed', sans-serif; font-weight: 800; font-size: 22px; color: #fff; letter-spacing: 1px; }
.ad-topbar-right { display: flex; align-items: center; gap: 8px; }
.ad-live-dot { width: 8px; height: 8px; border-radius: 50%; background: #3CAC3B; animation: blink 1.5s infinite; }
@keyframes blink { 0%,100%{opacity:1}50%{opacity:0.3} }
.ad-live-text { font-size: 13px; color: #3CAC3B; font-weight: 600; }
.ad-content { padding: 24px 28px; }

/* STAT CARDS */
.ad-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
.ad-stat-card { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 14px; padding: 20px; }
.ad-stat-header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
.ad-stat-icon { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px; background: rgba(201,165,90,0.1); }
.ad-stat-label { font-size: 12px; font-weight: 600; color: #667; text-transform: uppercase; letter-spacing: 0.5px; }
.ad-stat-value { font-family: 'Barlow Condensed', sans-serif; font-weight: 800; font-size: 28px; color: #fff; letter-spacing: 1px; }
.ad-stat-change { font-size: 12px; color: #3CAC3B; font-weight: 600; margin-top: 4px; }

/* CARDS */
.ad-card { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 14px; padding: 24px; margin-bottom: 20px; }
.ad-card-title { font-family: 'Barlow Condensed', sans-serif; font-weight: 800; font-size: 18px; color: #fff; letter-spacing: 1px; margin-bottom: 16px; }
.ad-row { display: flex; gap: 20px; }
.ad-row .flex1 { flex: 1; }
.ad-row .flex2 { flex: 2; }
@media (max-width: 900px) { .ad-row { flex-direction: column; } .ad-side { display: none; } }

/* BAR CHART */
.ad-bar-chart { display: flex; align-items: flex-end; gap: 32px; height: 160px; padding: 0 24px; }
.ad-bar-col { display: flex; flex-direction: column; align-items: center; flex: 1; }
.ad-bar-stack { display: flex; flex-direction: column-reverse; gap: 2px; }
.ad-bar { border-radius: 4px 4px 0 0; min-width: 40px; transition: height 0.5s; }
.ad-bar.free { background: #1B9ED3; }
.ad-bar.golden { background: #C9A55A; }
.ad-bar.champion { background: #E74C4C; }
.ad-bar-label { font-size: 12px; color: #667; font-weight: 700; margin-top: 8px; }
.ad-legend { display: flex; gap: 16px; justify-content: center; margin-top: 16px; font-size: 12px; color: #889; }
.ad-legend i { display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: 4px; vertical-align: middle; }

/* COUNTRIES */
.ad-countries { display: flex; flex-direction: column; gap: 10px; }
.ad-country-row { display: flex; align-items: center; gap: 10px; }
.ad-country-name { width: 110px; font-size: 13px; font-weight: 600; }
.ad-country-bar-bg { flex: 1; height: 8px; background: rgba(255,255,255,0.04); border-radius: 4px; overflow: hidden; }
.ad-country-bar { height: 100%; background: linear-gradient(90deg, #C9A55A, #E6793A); border-radius: 4px; transition: width 0.5s; }
.ad-country-pct { width: 40px; text-align: right; font-size: 12px; color: #C9A55A; font-weight: 700; }

/* SECURITY LOG */
.ad-log-list { display: flex; flex-direction: column; gap: 4px; }
.ad-log-row { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; font-size: 13px; transition: background 0.2s; }
.ad-log-row:hover { background: rgba(255,255,255,0.02); }
.ad-sev { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.ad-log-time { width: 80px; color: #556; font-size: 12px; }
.ad-log-event { flex: 1; font-weight: 600; color: #ddd; }
.ad-log-user { width: 100px; color: #889; font-size: 12px; }
.ad-log-ip { width: 100px; color: #556; font-size: 12px; font-family: monospace; }
.ad-sev-tag { font-size: 10px; font-weight: 800; letter-spacing: 1px; padding: 2px 8px; border-radius: 4px; }
.ad-sev-tag.high { background: rgba(231,76,76,0.1); color: #E74C4C; }
.ad-sev-tag.medium { background: rgba(230,121,58,0.1); color: #E6793A; }
.ad-sev-tag.low { background: rgba(201,165,90,0.1); color: #C9A55A; }
.ad-sev-tag.info { background: rgba(60,172,59,0.1); color: #3CAC3B; }

/* TOOLBAR */
.ad-toolbar { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
.ad-search { flex: 1; min-width: 200px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); border-radius: 10px; padding: 10px 14px; color: #fff; font-family: 'Noto Sans', sans-serif; font-size: 14px; outline: none; }
.ad-search:focus { border-color: #C9A55A; }
.ad-filters { display: flex; gap: 6px; }
.ad-filter-btn { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06); color: #889; font-family: 'Noto Sans', sans-serif; font-size: 12px; font-weight: 600; padding: 8px 14px; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
.ad-filter-btn.active { background: rgba(201,165,90,0.08); border-color: #C9A55A; color: #C9A55A; }

/* TABLE */
.ad-table-header { display: flex; align-items: center; padding: 10px 12px; font-size: 11px; font-weight: 700; color: #556; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid rgba(255,255,255,0.05); }
.ad-table-row { display: flex; align-items: center; padding: 12px 12px; border-bottom: 1px solid rgba(255,255,255,0.02); font-size: 13px; transition: background 0.2s; }
.ad-table-row:hover { background: rgba(255,255,255,0.015); }
.ad-table-row.flagged { background: rgba(231,76,76,0.03); }
.ad-user-cell { display: flex; flex-direction: column; }
.ad-user-name { font-weight: 700; color: #fff; font-size: 14px; }
.ad-user-email { font-size: 11px; color: #556; }
.ad-tier-badge { font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 4px; letter-spacing: 0.5px; }
.ad-tier-badge.champ { background: rgba(231,76,76,0.1); color: #E74C4C; }
.ad-tier-badge.gold { background: rgba(201,165,90,0.1); color: #C9A55A; }
.ad-tier-badge.free { background: rgba(255,255,255,0.04); color: #889; }
.ad-status { font-size: 12px; font-weight: 600; }
.ad-status.active { color: #3CAC3B; }
.ad-status.flagged { color: #E6793A; }
.ad-status.suspended { color: #E74C4C; }
.ad-action-btn { width: 28px; height: 28px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.06); background: rgba(255,255,255,0.02); cursor: pointer; font-size: 12px; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
.ad-action-btn:hover { background: rgba(255,255,255,0.06); }
.ad-action-btn.warn:hover { background: rgba(230,121,58,0.1); border-color: #E6793A; }
.ad-action-btn.danger:hover { background: rgba(231,76,76,0.1); border-color: #E74C4C; }

/* PREDICTION DISTRIBUTION */
.ad-pred-dist { display: flex; flex-direction: column; gap: 10px; }
.ad-pred-row { display: flex; align-items: center; gap: 12px; }
.ad-pred-team { width: 130px; font-size: 14px; font-weight: 600; }
.ad-pred-bar-bg { flex: 1; height: 10px; background: rgba(255,255,255,0.04); border-radius: 5px; overflow: hidden; }
.ad-pred-bar { height: 100%; background: linear-gradient(90deg, #C9A55A, #E6793A); border-radius: 5px; transition: width 0.6s; }
.ad-pred-bar.green { background: linear-gradient(90deg, #3CAC3B, #1B9ED3); }
.ad-pred-pct { width: 45px; text-align: right; font-size: 13px; color: #C9A55A; font-weight: 700; }

/* GROUP GRID */
.ad-group-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; }
.ad-group-item { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 10px; padding: 14px; }
.ad-group-letter { font-family: 'Barlow Condensed', sans-serif; font-weight: 800; font-size: 14px; color: #C9A55A; letter-spacing: 1px; margin-bottom: 4px; }
.ad-group-pick { font-size: 13px; font-weight: 600; color: #ddd; }

/* PAYMENT GRID */
.ad-pay-grid { display: flex; flex-direction: column; gap: 10px; }
.ad-pay-row { display: flex; align-items: center; gap: 12px; }
.ad-pay-method { width: 130px; font-size: 14px; font-weight: 600; }
.ad-pay-amount { width: 80px; text-align: right; font-size: 13px; font-weight: 700; color: #3CAC3B; }
.ad-pay-pct { width: 45px; text-align: right; font-size: 12px; color: #889; }

/* THREATS */
.ad-threat-list { display: flex; flex-direction: column; gap: 12px; }
.ad-threat-row { display: flex; align-items: center; gap: 10px; }
.ad-threat-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
.ad-threat-type { flex: 1; font-size: 13px; font-weight: 600; }
.ad-threat-count { font-family: 'Barlow Condensed', sans-serif; font-weight: 700; font-size: 18px; color: #fff; }

/* QUICK ACTIONS */
.ad-quick-actions { display: flex; flex-direction: column; gap: 8px; }

/* BUTTONS */
.ad-btn { font-family: 'Barlow Condensed', sans-serif; font-weight: 700; font-size: 13px; letter-spacing: 1px; padding: 10px 18px; border-radius: 8px; border: none; cursor: pointer; transition: all 0.2s; text-transform: uppercase; }
.ad-btn.gold { background: linear-gradient(135deg, #C9A55A, #8B6F2E); color: #000; }
.ad-btn.outline { background: transparent; border: 1px solid rgba(255,255,255,0.1); color: #aab; }
.ad-btn.outline:hover { border-color: #C9A55A; color: #C9A55A; }
.ad-btn.danger { background: rgba(231,76,76,0.1); border: 1px solid rgba(231,76,76,0.2); color: #E74C4C; }
.ad-btn.full { width: 100%; }

/* MODAL */
.ad-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; z-index: 100; padding: 24px; }
.ad-modal { background: #141B27; border: 1px solid rgba(255,255,255,0.06); border-radius: 20px; padding: 32px; max-width: 500px; width: 100%; position: relative; }
.ad-modal-close { position: absolute; top: 14px; right: 14px; background: none; border: none; color: #556; font-size: 16px; cursor: pointer; }
.ad-modal-title { font-family: 'Barlow Condensed', sans-serif; font-weight: 900; font-size: 24px; color: #fff; letter-spacing: 1px; margin-bottom: 20px; }
.ad-detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 24px; }
.ad-detail-item { }
.ad-detail-label { font-size: 11px; font-weight: 700; color: #556; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 2px; }
.ad-detail-value { font-size: 14px; font-weight: 600; color: #fff; }
.ad-modal-actions { display: flex; gap: 8px; flex-wrap: wrap; }
`;
