import { useState, useEffect, useRef, useCallback } from "react";

/* ─── DATA ─── */
const GROUPS = {
  A: [
    { code: "🇺🇸", name: "USA" }, { code: "🇲🇦", name: "Morocco" },
    { code: "🇲🇽", name: "Mexico" }, { code: "🇯🇲", name: "Jamaica" },
  ],
  B: [
    { code: "🇵🇹", name: "Portugal" }, { code: "🇪🇨", name: "Ecuador" },
    { code: "🇧🇴", name: "Bolivia" }, { code: "🇨🇦", name: "Canada" },
  ],
  C: [
    { code: "🇦🇷", name: "Argentina" }, { code: "🇪🇬", name: "Egypt" },
    { code: "🇺🇿", name: "Uzbekistan" }, { code: "🇮🇩", name: "Indonesia" },
  ],
  D: [
    { code: "🇫🇷", name: "France" }, { code: "🇨🇴", name: "Colombia" },
    { code: "🇳🇿", name: "New Zealand" }, { code: "🇧🇭", name: "Bahrain" },
  ],
  E: [
    { code: "🇧🇷", name: "Brazil" }, { code: "🇳🇬", name: "Nigeria" },
    { code: "🇦🇺", name: "Australia" }, { code: "🇹🇷", name: "Turkey" },
  ],
  F: [
    { code: "🇩🇪", name: "Germany" }, { code: "🇺🇾", name: "Uruguay" },
    { code: "🇵🇦", name: "Panama" }, { code: "🇰🇷", name: "South Korea" },
  ],
  G: [
    { code: "🇪🇸", name: "Spain" }, { code: "🇯🇵", name: "Japan" },
    { code: "🇷🇸", name: "Serbia" }, { code: "🇵🇾", name: "Paraguay" },
  ],
  H: [
    { code: "🇬🇧", name: "England" }, { code: "🇨🇱", name: "Chile" },
    { code: "🇸🇳", name: "Senegal" }, { code: "🇦🇱", name: "Albania" },
  ],
  I: [
    { code: "🇳🇱", name: "Netherlands" }, { code: "🇨🇷", name: "Costa Rica" },
    { code: "🇨🇲", name: "Cameroon" }, { code: "🇭🇷", name: "Croatia" },
  ],
  J: [
    { code: "🇧🇪", name: "Belgium" }, { code: "🇵🇪", name: "Peru" },
    { code: "🇮🇷", name: "Iran" }, { code: "🇩🇰", name: "Denmark" },
  ],
  K: [
    { code: "🇮🇹", name: "Italy" }, { code: "🇦🇹", name: "Austria" },
    { code: "🇸🇦", name: "Saudi Arabia" }, { code: "🇶🇦", name: "Qatar" },
  ],
  L: [
    { code: "🇨🇭", name: "Switzerland" }, { code: "🇬🇭", name: "Ghana" },
    { code: "🇹🇳", name: "Tunisia" }, { code: "🏴󠁧󠁢󠁷󠁬󠁳󠁿", name: "Wales" },
  ],
};

const UPCOMING = [
  { home: "USA", away: "Morocco", homeCode: "🇺🇸", awayCode: "🇲🇦", date: "Jun 11", time: "20:00 ET", stadium: "SoFi Stadium, LA" },
  { home: "Argentina", away: "Egypt", homeCode: "🇦🇷", awayCode: "🇪🇬", date: "Jun 12", time: "18:00 ET", stadium: "Hard Rock Stadium, Miami" },
  { home: "Brazil", away: "Nigeria", homeCode: "🇧🇷", awayCode: "🇳🇬", date: "Jun 12", time: "21:00 ET", stadium: "Rose Bowl, LA" },
  { home: "England", away: "Chile", homeCode: "🇬🇧", awayCode: "🇨🇱", date: "Jun 13", time: "17:00 ET", stadium: "MetLife Stadium, NY" },
  { home: "France", away: "Colombia", homeCode: "🇫🇷", awayCode: "🇨🇴", date: "Jun 13", time: "20:00 ET", stadium: "AT&T Stadium, Dallas" },
  { home: "Germany", away: "Uruguay", homeCode: "🇩🇪", awayCode: "🇺🇾", date: "Jun 14", time: "15:00 ET", stadium: "NRG Stadium, Houston" },
];

const LEADERBOARD = [
  { rank: 1, name: "AdemolaKing", pts: 2450, country: "🇳🇬", acc: "87%" },
  { rank: 2, name: "SambaFan99", pts: 2380, country: "🇧🇷", acc: "84%" },
  { rank: 3, name: "GoalMachine", pts: 2310, country: "🇬🇧", acc: "82%" },
  { rank: 4, name: "FutbolGuru", pts: 2250, country: "🇪🇸", acc: "81%" },
  { rank: 5, name: "ThreeStars", pts: 2180, country: "🇦🇷", acc: "79%" },
  { rank: 6, name: "OranjeArmy", pts: 2100, country: "🇳🇱", acc: "78%" },
  { rank: 7, name: "DerKaiser21", pts: 2050, country: "🇩🇪", acc: "76%" },
  { rank: 8, name: "AzzurriFan", pts: 1990, country: "🇮🇹", acc: "75%" },
  { rank: 9, name: "LesBleus10", pts: 1920, country: "🇫🇷", acc: "73%" },
  { rank: 10, name: "SuperEagle9", pts: 1870, country: "🇳🇬", acc: "72%" },
];

const TIERS = [
  {
    name: "Free Kick",
    price: "$0",
    period: "forever",
    color: "#8ca8bf",
    features: ["Predict match winners", "Basic leaderboard", "1 tournament prediction", "Community access"],
    cta: "Play Free",
  },
  {
    name: "Golden Boot",
    price: "$9.99",
    period: "/ tournament",
    color: "#C9A55A",
    popular: true,
    features: [
      "All Free Kick features",
      "Predict exact scores (+3× pts)",
      "Top scorer & MVP picks",
      "Advanced analytics",
      "2× prize multiplier",
      "Priority support",
    ],
    cta: "Upgrade Now",
  },
  {
    name: "World Champion",
    price: "$24.99",
    period: "/ tournament",
    color: "#E74C4C",
    features: [
      "All Golden Boot features",
      "Every match phase predictions",
      "Private prediction leagues",
      "Real-time match alerts",
      "5× prize multiplier",
      "Exclusive merch & badges",
    ],
    cta: "Go Champion",
  },
];

const PAYMENT_METHODS = [
  { name: "Stripe", icon: "💳", region: "Global", desc: "Visa, Mastercard, Amex" },
  { name: "PayPal", icon: "🅿️", region: "Global", desc: "200+ countries" },
  { name: "Apple Pay", icon: "🍎", region: "Global", desc: "iOS & Safari" },
  { name: "Google Pay", icon: "📱", region: "Global", desc: "Android & Chrome" },
  { name: "Paystack", icon: "🏦", region: "Africa", desc: "NGN, GHS, ZAR, KES" },
  { name: "Flutterwave", icon: "🦋", region: "Africa", desc: "30+ African countries" },
  { name: "M-Pesa", icon: "📲", region: "East Africa", desc: "Mobile money" },
  { name: "Crypto", icon: "₿", region: "Global", desc: "BTC, ETH, USDT" },
];

/* ─── SECURITY UTILS ─── */
const sanitize = (str) => {
  const map = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" };
  return String(str).replace(/[&<>"']/g, (m) => map[m]);
};

const validateEmail = (e) => /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/.test(e);
const validateUsername = (u) => /^[a-zA-Z0-9_]{3,20}$/.test(u);

const genToken = () => {
  const a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  return Array.from({ length: 32 }, () => a[Math.floor(Math.random() * a.length)]).join("");
};

/* ─── HOOKS ─── */
function useCountdown(target) {
  const [left, setLeft] = useState({});
  useEffect(() => {
    const calc = () => {
      const d = new Date(target) - new Date();
      if (d <= 0) return { d: 0, h: 0, m: 0, s: 0 };
      return {
        d: Math.floor(d / 86400000),
        h: Math.floor((d % 86400000) / 3600000),
        m: Math.floor((d % 3600000) / 60000),
        s: Math.floor((d % 60000) / 1000),
      };
    };
    setLeft(calc());
    const i = setInterval(() => setLeft(calc()), 1000);
    return () => clearInterval(i);
  }, [target]);
  return left;
}

function AnimNum({ value, dur = 1800 }) {
  const [n, setN] = useState(0);
  const ref = useRef(null);
  const ran = useRef(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !ran.current) {
        ran.current = true;
        let s = 0;
        const step = value / (dur / 16);
        const iv = setInterval(() => {
          s += step;
          if (s >= value) { setN(value); clearInterval(iv); }
          else setN(Math.floor(s));
        }, 16);
      }
    }, { threshold: 0.3 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [value, dur]);
  return <span ref={ref}>{n.toLocaleString()}</span>;
}

/* ─── MAIN ─── */
export default function GoalPlot() {
  const [page, setPage] = useState("home");
  const [winner, setWinner] = useState("");
  const [group, setGroup] = useState("A");
  const [picks, setPicks] = useState({});
  const [matchPreds, setMatchPreds] = useState({});
  const [email, setEmail] = useState("");
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [modal, setModal] = useState(null);
  const [registered, setRegistered] = useState(false);
  const [errors, setErrors] = useState({});
  const [attempts, setAttempts] = useState(0);
  const [locked, setLocked] = useState(false);
  const [csrf] = useState(genToken);
  const [menuOpen, setMenuOpen] = useState(false);

  const countdown = useCountdown("2026-06-11T00:00:00");

  const handleRegister = useCallback(() => {
    if (locked) return;
    const errs = {};
    if (!validateUsername(user)) errs.user = "3-20 chars, letters/numbers/underscore only";
    if (!validateEmail(email)) errs.email = "Enter a valid email";
    if (pass.length < 8) errs.pass = "Minimum 8 characters";
    if (!/[A-Z]/.test(pass)) errs.pass = "Must include uppercase letter";
    if (!/[0-9]/.test(pass)) errs.pass = "Must include a number";
    if (!/[^a-zA-Z0-9]/.test(pass)) errs.pass = "Must include a special character";
    setErrors(errs);
    if (Object.keys(errs).length) {
      setAttempts((a) => a + 1);
      if (attempts >= 4) {
        setLocked(true);
        setTimeout(() => { setLocked(false); setAttempts(0); }, 30000);
      }
      return;
    }
    setRegistered(true);
  }, [user, email, pass, attempts, locked]);

  const nav = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "predict", label: "Predict", icon: "🎯" },
    { id: "leaderboard", label: "Leaderboard", icon: "🏆" },
    { id: "pricing", label: "Plans", icon: "💎" },
    { id: "security", label: "Security", icon: "🔒" },
  ];

  return (
    <div className="gp-app">
      <style>{CSS}</style>

      {/* ═══ NAV ═══ */}
      <nav className="gp-nav">
        <div className="gp-nav-inner">
          <div className="gp-logo" onClick={() => setPage("home")}>
            <div className="gp-logo-mark">
              <span className="gp-logo-trophy">🏆</span>
              <span className="gp-logo-26">26</span>
            </div>
            <div className="gp-logo-text">
              <span className="gp-logo-goal">GOAL</span>
              <span className="gp-logo-plot">PLOT</span>
            </div>
          </div>
          <div className="gp-nav-links">
            {nav.map((n) => (
              <button key={n.id} className={`gp-nav-link ${page === n.id ? "active" : ""}`} onClick={() => setPage(n.id)}>
                {n.label}
              </button>
            ))}
          </div>
          <div className="gp-nav-actions">
            <button className="gp-btn-outline" onClick={() => setModal("login")}>Sign In</button>
            <button className="gp-btn-gold" onClick={() => setModal("register")}>Join Free</button>
          </div>
          <button className="gp-hamburger" onClick={() => setMenuOpen(!menuOpen)}>
            <span /><span /><span />
          </button>
        </div>
        {menuOpen && (
          <div className="gp-mobile-menu">
            {nav.map((n) => (
              <button key={n.id} className="gp-mobile-link" onClick={() => { setPage(n.id); setMenuOpen(false); }}>
                {n.icon} {n.label}
              </button>
            ))}
            <div style={{ display: "flex", gap: 8, padding: "12px 0" }}>
              <button className="gp-btn-outline" style={{ flex: 1 }} onClick={() => { setModal("login"); setMenuOpen(false); }}>Sign In</button>
              <button className="gp-btn-gold" style={{ flex: 1 }} onClick={() => { setModal("register"); setMenuOpen(false); }}>Join</button>
            </div>
          </div>
        )}
      </nav>

      {/* ═══ MODAL ═══ */}
      {modal && (
        <div className="gp-overlay" onClick={() => setModal(null)}>
          <div className="gp-modal" onClick={(e) => e.stopPropagation()}>
            <button className="gp-modal-x" onClick={() => setModal(null)}>✕</button>
            {!registered ? (
              <>
                <div className="gp-modal-trophy">🏆</div>
                <h2 className="gp-modal-title">{modal === "register" ? "Join GoalPlot" : "Welcome Back"}</h2>
                <p className="gp-modal-sub">{modal === "register" ? "Create your account — it's free" : "Sign in to your account"}</p>
                {locked && <div className="gp-error-banner">Too many attempts. Try again in 30 seconds.</div>}
                <div className="gp-form-group">
                  <label className="gp-label">Username</label>
                  <input className={`gp-input ${errors.user ? "error" : ""}`} placeholder="e.g. GoalKing26" value={user}
                    onChange={(e) => setUser(sanitize(e.target.value.replace(/[^a-zA-Z0-9_]/g, "")))} maxLength={20} />
                  {errors.user && <span className="gp-field-error">{errors.user}</span>}
                </div>
                <div className="gp-form-group">
                  <label className="gp-label">Email</label>
                  <input className={`gp-input ${errors.email ? "error" : ""}`} type="email" placeholder="you@example.com" value={email}
                    onChange={(e) => setEmail(e.target.value)} maxLength={100} />
                  {errors.email && <span className="gp-field-error">{errors.email}</span>}
                </div>
                <div className="gp-form-group">
                  <label className="gp-label">Password</label>
                  <input className={`gp-input ${errors.pass ? "error" : ""}`} type="password" placeholder="Min 8 chars, uppercase, number, symbol" value={pass}
                    onChange={(e) => setPass(e.target.value)} maxLength={64} />
                  {errors.pass && <span className="gp-field-error">{errors.pass}</span>}
                  {pass.length > 0 && (
                    <div className="gp-pass-strength">
                      <div className="gp-pass-bar" style={{
                        width: `${Math.min(100, (pass.length >= 8 ? 25 : 0) + (/[A-Z]/.test(pass) ? 25 : 0) + (/[0-9]/.test(pass) ? 25 : 0) + (/[^a-zA-Z0-9]/.test(pass) ? 25 : 0))}%`,
                        background: pass.length < 8 ? "#E74C4C" : /[A-Z]/.test(pass) && /[0-9]/.test(pass) && /[^a-zA-Z0-9]/.test(pass) ? "#3CAC3B" : "#C9A55A"
                      }} />
                    </div>
                  )}
                </div>
                <input type="hidden" value={csrf} name="_csrf" />
                <button className="gp-btn-gold full" onClick={handleRegister} disabled={locked}>
                  {modal === "register" ? "Create Secure Account →" : "Sign In →"}
                </button>
                <div className="gp-modal-security">
                  <span>🔒</span> 256-bit encrypted · CSRF protected · Rate limited
                </div>
                <p className="gp-modal-toggle">
                  {modal === "register" ? "Already have an account?" : "Don't have an account?"}{" "}
                  <span onClick={() => { setModal(modal === "register" ? "login" : "register"); setErrors({}); }}>
                    {modal === "register" ? "Sign In" : "Register"}
                  </span>
                </p>
              </>
            ) : (
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 56, marginBottom: 16 }}>🎉</div>
                <h2 className="gp-modal-title">You're In, {user}!</h2>
                <p className="gp-modal-sub">Your account is secured. Start predicting now.</p>
                <button className="gp-btn-gold full" onClick={() => { setModal(null); setPage("predict"); }}>
                  Start Predicting →
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════ HOME ═══════════ */}
      {page === "home" && (
        <>
          {/* HERO */}
          <section className="gp-hero">
            <div className="gp-hero-pattern" />
            <div className="gp-hero-glow" />
            <div className="gp-hero-content">
              <div className="gp-hero-badge">
                <span className="gp-badge-dot" />
                FIFA WORLD CUP 2026 — USA · CANADA · MEXICO
              </div>
              <h1 className="gp-hero-h1">
                PREDICT THE<br />
                <span className="gp-hero-gold">WORLD CUP</span> WINNER.<br />
                WIN A <span className="gp-hero-multi">PLOT OF LAND.</span>
              </h1>
              <p className="gp-hero-sub">
                Make your predictions for every match of the 2026 FIFA World Cup.
                The top predictor wins a verified <strong>100sqm plot of land</strong>.
                Free to play. Real prize. Global competition.
              </p>
              <div className="gp-hero-btns">
                <button className="gp-btn-gold big" onClick={() => setModal("register")}>
                  Start Predicting — It's Free
                </button>
                <button className="gp-btn-outline big" onClick={() => setPage("security")}>
                  🔒 How We Keep You Safe
                </button>
              </div>

              {/* COUNTDOWN */}
              <div className="gp-countdown">
                <div className="gp-countdown-label">Tournament Kicks Off In</div>
                <div className="gp-countdown-grid">
                  {[
                    { v: countdown.d, l: "Days" }, { v: countdown.h, l: "Hours" },
                    { v: countdown.m, l: "Mins" }, { v: countdown.s, l: "Secs" },
                  ].map((c) => (
                    <div key={c.l} className="gp-countdown-cell">
                      <div className="gp-countdown-num">{String(c.v || 0).padStart(2, "0")}</div>
                      <div className="gp-countdown-lbl">{c.l}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* STATS */}
              <div className="gp-hero-stats">
                <div className="gp-stat"><div className="gp-stat-num"><AnimNum value={48320} />+</div><div className="gp-stat-lbl">Predictors</div></div>
                <div className="gp-stat-divider" />
                <div className="gp-stat"><div className="gp-stat-num gold">100sqm</div><div className="gp-stat-lbl">Land Prize</div></div>
                <div className="gp-stat-divider" />
                <div className="gp-stat"><div className="gp-stat-num">48</div><div className="gp-stat-lbl">Teams</div></div>
                <div className="gp-stat-divider" />
                <div className="gp-stat"><div className="gp-stat-num">104</div><div className="gp-stat-lbl">Matches</div></div>
              </div>
            </div>
          </section>

          {/* AD */}
          <div className="gp-ad-strip">
            <span className="gp-ad-tag">SPONSOR</span>
            Your Brand Here — Reach 48,000+ Global Football Fans — <span className="gp-ad-cta">Advertise With GoalPlot</span>
          </div>

          {/* HOW IT WORKS */}
          <section className="gp-section">
            <h2 className="gp-section-title">HOW IT WORKS</h2>
            <div className="gp-section-line" />
            <p className="gp-section-sub">Three steps to your shot at winning real land</p>
            <div className="gp-steps">
              {[
                { n: "01", icon: "📝", title: "Sign Up Free", desc: "Create your account in seconds. No payment needed to play the free tier. Open to everyone globally." },
                { n: "02", icon: "🎯", title: "Make Predictions", desc: "Predict match winners, exact scores, group winners, and the overall champion. Earn points for accuracy." },
                { n: "03", icon: "🏡", title: "Win The Plot", desc: "Top the leaderboard at the final whistle. The highest-scoring predictor wins a verified 100sqm plot of land." },
              ].map((s, i) => (
                <div key={s.n} className="gp-step" style={{ animationDelay: `${i * 0.15}s` }}>
                  <div className="gp-step-num">{s.n}</div>
                  <div className="gp-step-icon">{s.icon}</div>
                  <h3 className="gp-step-title">{s.title}</h3>
                  <p className="gp-step-desc">{s.desc}</p>
                </div>
              ))}
            </div>
          </section>

          {/* UPCOMING MATCHES */}
          <section className="gp-section dark">
            <h2 className="gp-section-title">UPCOMING MATCHES</h2>
            <div className="gp-section-line" />
            <p className="gp-section-sub">Predict these opening fixtures and earn early points</p>
            <div className="gp-matches-grid">
              {UPCOMING.map((m, i) => (
                <div key={i} className="gp-match-card">
                  <div className="gp-match-date">{m.date} · {m.time}</div>
                  <div className="gp-match-teams">
                    <div className="gp-match-team">
                      <span className="gp-team-flag">{m.homeCode}</span>
                      <span className="gp-team-name">{m.home}</span>
                    </div>
                    <span className="gp-match-vs">VS</span>
                    <div className="gp-match-team">
                      <span className="gp-team-flag">{m.awayCode}</span>
                      <span className="gp-team-name">{m.away}</span>
                    </div>
                  </div>
                  <div className="gp-match-stadium">{m.stadium}</div>
                  <button className="gp-btn-outline small" onClick={() => { setPage("predict"); }}>Predict →</button>
                </div>
              ))}
            </div>
          </section>

          {/* PRIZE */}
          <section className="gp-prize">
            <div className="gp-prize-inner">
              <div className="gp-prize-left">
                <div className="gp-prize-badge">🏡 GRAND PRIZE</div>
                <h2 className="gp-prize-title">100sqm<br />Plot of Land</h2>
                <p className="gp-prize-desc">
                  A verified, legally documented plot of land with genuine title documentation.
                  Winner announced live after the final. Handover completed within 30 days.
                </p>
                <div className="gp-prize-checks">
                  {["Verified title & survey documents", "Independent legal verification", "Transparent on-chain selection", "Live-streamed winner announcement"].map((c) => (
                    <div key={c} className="gp-prize-check">✓ {c}</div>
                  ))}
                </div>
              </div>
              <div className="gp-prize-right">
                <div className="gp-prize-visual">
                  <div className="gp-plot-grid">
                    {Array.from({ length: 25 }).map((_, i) => (
                      <div key={i} className="gp-plot-cell" style={{ animationDelay: `${i * 0.08}s` }} />
                    ))}
                  </div>
                  <div className="gp-plot-label">100 SQM</div>
                  <div className="gp-plot-sub">Your future land</div>
                </div>
              </div>
            </div>
          </section>

          {/* MINI LEADERBOARD */}
          <section className="gp-section">
            <h2 className="gp-section-title">LIVE LEADERBOARD</h2>
            <div className="gp-section-line" />
            <div className="gp-mini-board">
              {LEADERBOARD.slice(0, 5).map((p, i) => (
                <div key={p.rank} className={`gp-mini-row ${i < 3 ? "top" : ""}`}>
                  <div className="gp-mini-rank">{i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${p.rank}`}</div>
                  <div className="gp-mini-name">{p.country} {p.name}</div>
                  <div className="gp-mini-acc">{p.acc}</div>
                  <div className="gp-mini-pts">{p.pts.toLocaleString()} pts</div>
                </div>
              ))}
            </div>
            <button className="gp-btn-outline" style={{ display: "block", margin: "24px auto 0" }} onClick={() => setPage("leaderboard")}>
              View Full Leaderboard →
            </button>
          </section>

          {/* GLOBAL PAYMENTS */}
          <section className="gp-section dark">
            <h2 className="gp-section-title">GLOBAL PAYMENTS</h2>
            <div className="gp-section-line" />
            <p className="gp-section-sub">Upgrade to premium from anywhere in the world</p>
            <div className="gp-payments-grid">
              {PAYMENT_METHODS.map((p) => (
                <div key={p.name} className="gp-payment-card">
                  <div className="gp-payment-icon">{p.icon}</div>
                  <div className="gp-payment-name">{p.name}</div>
                  <div className="gp-payment-region">{p.region}</div>
                  <div className="gp-payment-desc">{p.desc}</div>
                </div>
              ))}
            </div>
          </section>

          {/* SPONSORS */}
          <section className="gp-sponsors">
            <div className="gp-sponsor-label">OFFICIAL PARTNERS</div>
            <div className="gp-sponsor-row">
              {["🏦 GlobalBank", "📱 TechMobile", "🏗️ BuildRight", "🎮 GameZone", "✈️ FlyWorld", "⚡ PowerUp"].map((s) => (
                <div key={s} className="gp-sponsor-item">{s}</div>
              ))}
            </div>
            <p className="gp-sponsor-cta">Want to be a sponsor? <span>Contact Us</span></p>
          </section>
        </>
      )}

      {/* ═══════════ PREDICT ═══════════ */}
      {page === "predict" && (
        <section className="gp-page">
          <h2 className="gp-page-title">MAKE YOUR PREDICTIONS</h2>
          <div className="gp-section-line" />
          <p className="gp-page-sub">Pick winners for each group and predict the overall champion</p>

          {/* OVERALL WINNER */}
          <div className="gp-winner-section">
            <h3 className="gp-winner-label">🏆 YOUR WORLD CUP WINNER</h3>
            <div className="gp-winner-scroll">
              {Object.values(GROUPS).flat().map((t) => (
                <button key={t.name} className={`gp-winner-chip ${winner === t.name ? "active" : ""}`} onClick={() => setWinner(t.name)}>
                  <span style={{ fontSize: 24 }}>{t.code}</span>
                  <span className="gp-winner-chip-name">{t.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* MATCH PREDICTIONS */}
          <div className="gp-predict-matches">
            <h3 className="gp-predict-subtitle">⚽ OPENING MATCH PREDICTIONS</h3>
            {UPCOMING.slice(0, 3).map((m, i) => (
              <div key={i} className="gp-pred-match">
                <div className="gp-pred-header">{m.date} · {m.stadium}</div>
                <div className="gp-pred-row">
                  <button className={`gp-pred-pick ${matchPreds[i] === "home" ? "active" : ""}`}
                    onClick={() => setMatchPreds((p) => ({ ...p, [i]: "home" }))}>
                    <span style={{ fontSize: 28 }}>{m.homeCode}</span>
                    <span>{m.home}</span>
                  </button>
                  <button className={`gp-pred-pick draw ${matchPreds[i] === "draw" ? "active" : ""}`}
                    onClick={() => setMatchPreds((p) => ({ ...p, [i]: "draw" }))}>
                    Draw
                  </button>
                  <button className={`gp-pred-pick ${matchPreds[i] === "away" ? "active" : ""}`}
                    onClick={() => setMatchPreds((p) => ({ ...p, [i]: "away" }))}>
                    <span style={{ fontSize: 28 }}>{m.awayCode}</span>
                    <span>{m.away}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* GROUP PREDICTIONS */}
          <div className="gp-group-section">
            <h3 className="gp-predict-subtitle">🏅 GROUP STAGE — PICK EACH WINNER</h3>
            <div className="gp-group-tabs">
              {Object.keys(GROUPS).map((g) => (
                <button key={g} className={`gp-group-tab ${group === g ? "active" : ""}`} onClick={() => setGroup(g)}>{g}</button>
              ))}
            </div>
            <div className="gp-group-card">
              <h4 className="gp-group-name">Group {group}</h4>
              <div className="gp-group-teams">
                {GROUPS[group].map((t) => (
                  <button key={t.name} className={`gp-team-btn ${picks[group] === t.name ? "active" : ""}`}
                    onClick={() => setPicks((p) => ({ ...p, [group]: t.name }))}>
                    <span className="gp-team-flag-big">{t.code}</span>
                    <span className="gp-team-name-big">{t.name}</span>
                    {picks[group] === t.name && <span className="gp-check">✓</span>}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* VIP PROMO */}
          <div className="gp-vip-promo">
            <span className="gp-ad-tag">VIP</span>
            Upgrade to <strong style={{ color: "#C9A55A" }}>Golden Boot</strong> for 2× points on every correct prediction{" "}
            <span className="gp-ad-cta" onClick={() => setPage("pricing")}>Upgrade Now →</span>
          </div>

          {/* SUMMARY */}
          <div className="gp-summary">
            <h4 className="gp-summary-title">Your Predictions Summary</h4>
            <div className="gp-summary-chips">
              {winner && <div className="gp-chip gold">🏆 Winner: {winner}</div>}
              {Object.entries(matchPreds).map(([k, v]) => (
                <div key={k} className="gp-chip">{UPCOMING[k]?.home} vs {UPCOMING[k]?.away}: {v === "home" ? UPCOMING[k]?.home : v === "away" ? UPCOMING[k]?.away : "Draw"}</div>
              ))}
              {Object.entries(picks).map(([g, t]) => (
                <div key={g} className="gp-chip">Group {g}: {t}</div>
              ))}
            </div>
            <button className="gp-btn-gold full" onClick={() => setModal("register")}>Submit All Predictions →</button>
          </div>
        </section>
      )}

      {/* ═══════════ LEADERBOARD ═══════════ */}
      {page === "leaderboard" && (
        <section className="gp-page">
          <h2 className="gp-page-title">🏆 LEADERBOARD</h2>
          <div className="gp-section-line" />
          <p className="gp-page-sub">Top predictors compete for the 100sqm land prize</p>
          <div className="gp-lb-podium">
            {[LEADERBOARD[1], LEADERBOARD[0], LEADERBOARD[2]].map((p, i) => (
              <div key={p.rank} className={`gp-podium-item p${i}`}>
                <div className="gp-podium-flag">{p.country}</div>
                <div className="gp-podium-name">{p.name}</div>
                <div className="gp-podium-pts">{p.pts.toLocaleString()} pts</div>
                <div className={`gp-podium-bar b${i}`}>
                  {i === 0 ? "🥈" : i === 1 ? "🥇" : "🥉"}
                </div>
              </div>
            ))}
          </div>
          <div className="gp-lb-table">
            <div className="gp-lb-header">
              <span style={{ width: 60 }}>Rank</span>
              <span style={{ flex: 1 }}>Predictor</span>
              <span style={{ width: 70, textAlign: "right" }}>Accuracy</span>
              <span style={{ width: 90, textAlign: "right" }}>Points</span>
            </div>
            {LEADERBOARD.map((p) => (
              <div key={p.rank} className={`gp-lb-row ${p.rank <= 3 ? "highlight" : ""}`}>
                <span style={{ width: 60, fontWeight: 800, color: p.rank <= 3 ? "#C9A55A" : "#666" }}>#{p.rank}</span>
                <span style={{ flex: 1, fontWeight: 600, color: "#fff" }}>{p.country} {p.name}</span>
                <span style={{ width: 70, textAlign: "right", color: "#3CAC3B" }}>{p.acc}</span>
                <span style={{ width: 90, textAlign: "right", fontWeight: 700, color: "#C9A55A" }}>{p.pts.toLocaleString()}</span>
              </div>
            ))}
          </div>
          {/* REFERRAL */}
          <div className="gp-referral">
            <h3>📣 Invite Friends, Earn Bonus Points</h3>
            <p>Share your link — earn 50 bonus points for every friend who joins and predicts.</p>
            <div className="gp-referral-link">
              <span>goalplot.com/ref/{user || "YOUR_USERNAME"}</span>
              <button className="gp-btn-gold small">Copy</button>
            </div>
          </div>
        </section>
      )}

      {/* ═══════════ PRICING ═══════════ */}
      {page === "pricing" && (
        <section className="gp-page">
          <h2 className="gp-page-title">💎 CHOOSE YOUR PLAN</h2>
          <div className="gp-section-line" />
          <p className="gp-page-sub">Boost your chances with premium features</p>
          <div className="gp-pricing-grid">
            {TIERS.map((t) => (
              <div key={t.name} className={`gp-pricing-card ${t.popular ? "popular" : ""}`}>
                {t.popular && <div className="gp-popular-tag">MOST POPULAR</div>}
                <h3 className="gp-pricing-name" style={{ color: t.color }}>{t.name}</h3>
                <div className="gp-pricing-price">{t.price}</div>
                <div className="gp-pricing-period">{t.period}</div>
                <div className="gp-pricing-features">
                  {t.features.map((f) => <div key={f} className="gp-pricing-feat">✦ {f}</div>)}
                </div>
                <button className={`gp-btn-gold full ${!t.popular ? "outline-v" : ""}`} onClick={() => setModal("register")}>{t.cta}</button>
              </div>
            ))}
          </div>
          <h3 className="gp-section-title" style={{ marginTop: 56 }}>ACCEPTED WORLDWIDE</h3>
          <div className="gp-section-line" />
          <div className="gp-payments-grid" style={{ marginTop: 32 }}>
            {PAYMENT_METHODS.map((p) => (
              <div key={p.name} className="gp-payment-card">
                <div className="gp-payment-icon">{p.icon}</div>
                <div className="gp-payment-name">{p.name}</div>
                <div className="gp-payment-region">{p.region}</div>
                <div className="gp-payment-desc">{p.desc}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ═══════════ SECURITY ═══════════ */}
      {page === "security" && (
        <section className="gp-page">
          <h2 className="gp-page-title">🔒 SECURITY & TRUST</h2>
          <div className="gp-section-line" />
          <p className="gp-page-sub">How GoalPlot protects you and your predictions</p>
          <div className="gp-security-grid">
            {[
              { icon: "🔐", title: "End-to-End Encryption", desc: "All data is encrypted using AES-256 in transit and at rest. Your predictions and personal information are never stored in plain text." },
              { icon: "🛡️", title: "CSRF Protection", desc: "Every session is protected with unique cryptographic tokens that prevent cross-site request forgery attacks." },
              { icon: "⏱️", title: "Rate Limiting", desc: "Automated brute-force protection locks accounts after multiple failed attempts with progressive cooldown." },
              { icon: "🧹", title: "Input Sanitization", desc: "All user inputs are sanitized to prevent XSS, SQL injection, and other code injection attacks." },
              { icon: "🔑", title: "Secure Authentication", desc: "Passwords are hashed with bcrypt (12 rounds). We never store plain-text passwords. 2FA available for all accounts." },
              { icon: "📜", title: "Transparent Selection", desc: "Winner selection is provably fair using blockchain-verified randomness. All prediction data is immutable once submitted." },
              { icon: "🌐", title: "PCI-DSS Compliant Payments", desc: "All payment processing is handled by certified PCI-DSS Level 1 providers. We never see or store your card details." },
              { icon: "🔍", title: "Independent Audits", desc: "Regular third-party security audits and penetration testing ensure our systems remain hardened against threats." },
            ].map((s) => (
              <div key={s.title} className="gp-security-card">
                <div className="gp-security-icon">{s.icon}</div>
                <h4 className="gp-security-title">{s.title}</h4>
                <p className="gp-security-desc">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="gp-security-banner">
            <h3>🏅 Our Security Promise</h3>
            <p>GoalPlot is built with security-first architecture. We use industry-standard protections including TLS 1.3, HTTP-only cookies, Content Security Policy headers, subresource integrity, and continuous monitoring. Your data never goes to any third party without your explicit consent.</p>
          </div>
        </section>
      )}

      {/* ═══ FOOTER ═══ */}
      <footer className="gp-footer">
        <div className="gp-footer-inner">
          <div className="gp-footer-brand">
            <div className="gp-logo" style={{ marginBottom: 12 }}>
              <div className="gp-logo-mark"><span className="gp-logo-trophy">🏆</span><span className="gp-logo-26">26</span></div>
              <div className="gp-logo-text"><span className="gp-logo-goal">GOAL</span><span className="gp-logo-plot">PLOT</span></div>
            </div>
            <p className="gp-footer-tagline">Predict the beautiful game. Win real land.</p>
            <div className="gp-footer-badges">
              <span className="gp-footer-badge">🔒 SSL Secured</span>
              <span className="gp-footer-badge">🛡️ PCI Compliant</span>
            </div>
          </div>
          <div className="gp-footer-cols">
            <div>
              <h5>Platform</h5>
              {["How It Works", "Predictions", "Leaderboard", "VIP Plans", "Rules & FAQ"].map((l) => <div key={l} className="gp-footer-link">{l}</div>)}
            </div>
            <div>
              <h5>Company</h5>
              {["About Us", "Contact", "Advertise", "Partners", "Careers"].map((l) => <div key={l} className="gp-footer-link">{l}</div>)}
            </div>
            <div>
              <h5>Legal</h5>
              {["Terms of Service", "Privacy Policy", "Cookie Policy", "Responsible Gaming", "Disclaimer"].map((l) => <div key={l} className="gp-footer-link">{l}</div>)}
            </div>
          </div>
        </div>
        <div className="gp-footer-bottom">
          © 2026 GoalPlot. All rights reserved. Not affiliated with FIFA or the FIFA World Cup™.
          <br />This is an independent prediction platform. Please play responsibly.
        </div>
      </footer>
    </div>
  );
}

/* ─── STYLES ─── */
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;500;600;700;800;900&family=Noto+Sans:wght@300;400;500;600;700;800&family=Bebas+Neue&display=swap');

:root {
  --gold: #C9A55A;
  --gold-light: #E8D5A3;
  --gold-dark: #8B6F2E;
  --green: #3CAC3B;
  --blue: #2A398D;
  --red: #E74C4C;
  --teal: #1B9ED3;
  --coral: #E6793A;
  --bg: #080B12;
  --bg2: #0D1117;
  --bg3: #141B27;
  --card: rgba(255,255,255,0.025);
  --border: rgba(255,255,255,0.06);
  --text: #E0E0E0;
  --text2: #8899AA;
  --text3: #556677;
  --display: 'Barlow Condensed', sans-serif;
  --body: 'Noto Sans', sans-serif;
  --accent: 'Bebas Neue', sans-serif;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
.gp-app { font-family: var(--body); background: var(--bg); color: var(--text); min-height: 100vh; overflow-x: hidden; -webkit-font-smoothing: antialiased; }

/* NAV */
.gp-nav { position: sticky; top: 0; z-index: 100; background: rgba(8,11,18,0.88); backdrop-filter: blur(24px); border-bottom: 1px solid var(--border); }
.gp-nav-inner { max-width: 1200px; margin: 0 auto; padding: 10px 24px; display: flex; align-items: center; gap: 16px; }
.gp-logo { display: flex; align-items: center; gap: 10px; cursor: pointer; user-select: none; }
.gp-logo-mark { position: relative; display: flex; align-items: center; }
.gp-logo-trophy { font-size: 26px; }
.gp-logo-26 { font-family: var(--accent); font-size: 20px; color: var(--gold); margin-left: 2px; letter-spacing: 1px; }
.gp-logo-text { display: flex; flex-direction: column; line-height: 1; }
.gp-logo-goal { font-family: var(--display); font-weight: 900; font-size: 22px; color: #fff; letter-spacing: 3px; }
.gp-logo-plot { font-family: var(--display); font-weight: 600; font-size: 13px; color: var(--gold); letter-spacing: 5px; }
.gp-nav-links { display: flex; gap: 4px; margin-left: auto; }
.gp-nav-link { background: none; border: none; font-family: var(--body); font-size: 13px; font-weight: 600; color: var(--text2); padding: 8px 14px; border-radius: 8px; cursor: pointer; transition: all 0.2s; letter-spacing: 0.5px; }
.gp-nav-link:hover { color: #fff; background: rgba(255,255,255,0.04); }
.gp-nav-link.active { color: var(--gold); background: rgba(201,165,90,0.08); }
.gp-nav-actions { display: flex; gap: 8px; margin-left: 12px; }
.gp-hamburger { display: none; background: none; border: none; cursor: pointer; padding: 8px; flex-direction: column; gap: 4px; }
.gp-hamburger span { display: block; width: 20px; height: 2px; background: #fff; border-radius: 1px; }
.gp-mobile-menu { padding: 8px 24px 16px; display: flex; flex-direction: column; gap: 2px; }
.gp-mobile-link { background: none; border: none; font-family: var(--body); font-size: 15px; color: var(--text); padding: 14px 0; text-align: left; cursor: pointer; border-bottom: 1px solid var(--border); }
@media (max-width: 768px) {
  .gp-nav-links, .gp-nav-actions { display: none; }
  .gp-hamburger { display: flex; margin-left: auto; }
  .gp-hero-h1 { font-size: 42px !important; }
  .gp-hero-stats { flex-direction: column; gap: 16px !important; }
  .gp-stat-divider { display: none; }
  .gp-prize-inner { grid-template-columns: 1fr !important; }
  .gp-pricing-grid { grid-template-columns: 1fr !important; }
  .gp-footer-inner { grid-template-columns: 1fr !important; }
  .gp-footer-cols { grid-template-columns: 1fr 1fr !important; }
  .gp-lb-podium { gap: 8px !important; }
  .gp-countdown-grid { gap: 8px !important; }
  .gp-matches-grid { grid-template-columns: 1fr !important; }
}

/* BUTTONS */
.gp-btn-gold { font-family: var(--display); font-weight: 700; font-size: 14px; letter-spacing: 1px; background: linear-gradient(135deg, var(--gold), var(--gold-dark)); color: #000; border: none; padding: 10px 24px; border-radius: 8px; cursor: pointer; transition: all 0.25s; text-transform: uppercase; }
.gp-btn-gold:hover { filter: brightness(1.15); transform: translateY(-1px); }
.gp-btn-gold.big { padding: 16px 36px; font-size: 15px; border-radius: 10px; }
.gp-btn-gold.small { padding: 8px 16px; font-size: 12px; }
.gp-btn-gold.full { width: 100%; padding: 16px; font-size: 15px; }
.gp-btn-gold.outline-v { background: transparent; border: 2px solid var(--border); color: #fff; }
.gp-btn-gold.outline-v:hover { border-color: var(--gold); color: var(--gold); }
.gp-btn-gold:disabled { opacity: 0.4; cursor: not-allowed; }
.gp-btn-outline { font-family: var(--display); font-weight: 600; font-size: 14px; letter-spacing: 1px; background: transparent; color: #fff; border: 1.5px solid rgba(255,255,255,0.15); padding: 10px 24px; border-radius: 8px; cursor: pointer; transition: all 0.25s; text-transform: uppercase; }
.gp-btn-outline:hover { border-color: var(--gold); color: var(--gold); }
.gp-btn-outline.big { padding: 16px 36px; font-size: 15px; border-radius: 10px; }
.gp-btn-outline.small { padding: 8px 16px; font-size: 12px; }

/* HERO */
.gp-hero { position: relative; padding: 80px 24px 60px; text-align: center; overflow: hidden; }
.gp-hero-pattern {
  position: absolute; inset: 0; opacity: 0.04;
  background-image: repeating-linear-gradient(0deg, transparent, transparent 60px, rgba(201,165,90,0.3) 60px, rgba(201,165,90,0.3) 61px),
    repeating-linear-gradient(90deg, transparent, transparent 60px, rgba(201,165,90,0.3) 60px, rgba(201,165,90,0.3) 61px);
}
.gp-hero-glow { position: absolute; top: -120px; left: 50%; transform: translateX(-50%); width: 800px; height: 600px; background: radial-gradient(ellipse, rgba(201,165,90,0.08) 0%, transparent 70%); pointer-events: none; }
.gp-hero-content { position: relative; max-width: 820px; margin: 0 auto; }
.gp-hero-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(201,165,90,0.08); border: 1px solid rgba(201,165,90,0.15); border-radius: 100px; padding: 8px 20px; font-family: var(--body); font-size: 12px; font-weight: 700; color: var(--gold); letter-spacing: 1.5px; margin-bottom: 32px; animation: fadeUp 0.5s ease both; }
.gp-badge-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--green); animation: blink 1.5s infinite; }
@keyframes blink { 0%,100%{ opacity:1 } 50%{ opacity:0.3 } }
.gp-hero-h1 { font-family: var(--display); font-weight: 900; font-size: clamp(46px,7.5vw,82px); line-height: 1.0; color: #fff; letter-spacing: 2px; margin-bottom: 24px; animation: fadeUp 0.7s ease both; }
.gp-hero-gold { color: var(--gold); }
.gp-hero-multi { background: linear-gradient(90deg, var(--green), var(--teal), var(--coral), var(--red)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
.gp-hero-sub { font-size: 16px; line-height: 1.8; color: var(--text2); max-width: 560px; margin: 0 auto 36px; animation: fadeUp 0.9s ease both; }
.gp-hero-sub strong { color: var(--gold); }
.gp-hero-btns { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; margin-bottom: 40px; animation: fadeUp 1.1s ease both; }

/* COUNTDOWN */
.gp-countdown { margin-bottom: 40px; animation: fadeUp 1.3s ease both; }
.gp-countdown-label { font-family: var(--display); font-size: 14px; font-weight: 600; letter-spacing: 3px; color: var(--text3); margin-bottom: 12px; text-transform: uppercase; }
.gp-countdown-grid { display: inline-flex; gap: 12px; }
.gp-countdown-cell { background: var(--bg3); border: 1px solid var(--border); border-radius: 12px; padding: 16px 20px; min-width: 72px; }
.gp-countdown-num { font-family: var(--accent); font-size: 36px; color: var(--gold); line-height: 1; }
.gp-countdown-lbl { font-size: 10px; font-weight: 700; color: var(--text3); letter-spacing: 2px; margin-top: 4px; text-transform: uppercase; }

/* STATS */
.gp-hero-stats { display: flex; justify-content: center; align-items: center; gap: 36px; flex-wrap: wrap; animation: fadeUp 1.5s ease both; }
.gp-stat { text-align: center; }
.gp-stat-num { font-family: var(--accent); font-size: 34px; color: #fff; letter-spacing: 1px; }
.gp-stat-num.gold { color: var(--gold); }
.gp-stat-lbl { font-size: 12px; color: var(--text3); margin-top: 2px; font-weight: 600; letter-spacing: 1px; text-transform: uppercase; }
.gp-stat-divider { width: 1px; height: 36px; background: var(--border); }

/* AD */
.gp-ad-strip { background: rgba(201,165,90,0.04); border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); padding: 12px 24px; text-align: center; font-size: 13px; color: var(--text3); }
.gp-ad-tag { background: rgba(201,165,90,0.12); color: var(--gold); padding: 2px 8px; border-radius: 3px; font-size: 10px; font-weight: 800; letter-spacing: 1px; margin-right: 10px; }
.gp-ad-cta { color: var(--gold); cursor: pointer; text-decoration: underline; font-weight: 600; }

/* SECTIONS */
.gp-section { max-width: 1100px; margin: 0 auto; padding: 72px 24px; }
.gp-section.dark { background: var(--bg2); max-width: 100%; }
.gp-section.dark > * { max-width: 1100px; margin-left: auto; margin-right: auto; }
.gp-section-title { font-family: var(--display); font-weight: 900; font-size: 36px; text-align: center; color: #fff; letter-spacing: 3px; }
.gp-section-line { width: 60px; height: 3px; background: var(--gold); margin: 12px auto 8px; border-radius: 2px; }
.gp-section-sub { text-align: center; color: var(--text2); font-size: 15px; margin-bottom: 40px; }

/* STEPS */
.gp-steps { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; }
.gp-step { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 36px 28px; text-align: center; animation: fadeUp 0.6s ease both; transition: transform 0.3s, border-color 0.3s; }
.gp-step:hover { border-color: rgba(201,165,90,0.2); transform: translateY(-4px); }
.gp-step-num { font-family: var(--accent); font-size: 48px; color: rgba(201,165,90,0.12); line-height: 1; margin-bottom: -8px; }
.gp-step-icon { font-size: 40px; margin-bottom: 16px; }
.gp-step-title { font-family: var(--display); font-weight: 800; font-size: 22px; color: #fff; margin-bottom: 10px; letter-spacing: 1px; }
.gp-step-desc { font-size: 14px; line-height: 1.7; color: var(--text2); }

/* MATCHES */
.gp-matches-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; padding: 0 24px; }
.gp-match-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 20px; text-align: center; transition: border-color 0.3s; }
.gp-match-card:hover { border-color: rgba(201,165,90,0.2); }
.gp-match-date { font-size: 12px; font-weight: 700; color: var(--gold); letter-spacing: 1px; margin-bottom: 12px; }
.gp-match-teams { display: flex; align-items: center; justify-content: center; gap: 16px; margin-bottom: 8px; }
.gp-match-team { display: flex; flex-direction: column; align-items: center; gap: 4px; }
.gp-team-flag { font-size: 32px; }
.gp-team-name { font-family: var(--display); font-weight: 700; font-size: 14px; color: #fff; letter-spacing: 1px; }
.gp-match-vs { font-family: var(--accent); font-size: 20px; color: var(--text3); }
.gp-match-stadium { font-size: 11px; color: var(--text3); margin-bottom: 12px; }

/* PRIZE */
.gp-prize { background: linear-gradient(180deg, rgba(201,165,90,0.04) 0%, transparent 100%); padding: 72px 24px; }
.gp-prize-inner { max-width: 1000px; margin: 0 auto; display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 48px; align-items: center; }
.gp-prize-badge { display: inline-block; background: rgba(201,165,90,0.1); border: 1px solid rgba(201,165,90,0.2); border-radius: 100px; padding: 6px 18px; font-family: var(--display); font-size: 13px; font-weight: 700; color: var(--gold); letter-spacing: 2px; margin-bottom: 20px; }
.gp-prize-title { font-family: var(--display); font-weight: 900; font-size: 52px; color: #fff; letter-spacing: 2px; margin-bottom: 16px; line-height: 1.05; }
.gp-prize-desc { font-size: 15px; line-height: 1.8; color: var(--text2); margin-bottom: 24px; }
.gp-prize-checks { display: flex; flex-direction: column; gap: 10px; }
.gp-prize-check { font-size: 14px; color: var(--text); font-weight: 500; }
.gp-prize-check::first-letter { color: var(--green); }
.gp-prize-right { display: flex; justify-content: center; }
.gp-prize-visual { text-align: center; }
.gp-plot-grid { display: grid; grid-template-columns: repeat(5, 44px); gap: 5px; margin-bottom: 16px; }
.gp-plot-cell { width: 44px; height: 44px; background: linear-gradient(135deg, rgba(201,165,90,0.2), rgba(60,172,59,0.15)); border: 1px solid rgba(201,165,90,0.25); border-radius: 5px; animation: plotPulse 3s ease infinite; }
@keyframes plotPulse { 0%,100%{ opacity:0.5;transform:scale(1) } 50%{ opacity:1;transform:scale(1.04) } }
.gp-plot-label { font-family: var(--accent); font-size: 36px; color: var(--gold); letter-spacing: 3px; }
.gp-plot-sub { font-size: 12px; color: var(--text3); font-weight: 600; letter-spacing: 1px; text-transform: uppercase; }

/* MINI BOARD */
.gp-mini-board { max-width: 560px; margin: 0 auto; background: var(--card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; }
.gp-mini-row { display: flex; align-items: center; padding: 14px 20px; border-bottom: 1px solid var(--border); gap: 12px; }
.gp-mini-row.top { background: rgba(201,165,90,0.03); }
.gp-mini-rank { width: 36px; font-size: 18px; text-align: center; }
.gp-mini-name { flex: 1; font-weight: 600; color: #fff; font-size: 14px; }
.gp-mini-acc { font-size: 12px; color: var(--green); font-weight: 700; }
.gp-mini-pts { font-size: 13px; color: var(--gold); font-weight: 700; width: 80px; text-align: right; }

/* PAYMENTS */
.gp-payments-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 14px; padding: 0 24px; }
.gp-payment-card { background: var(--card); border: 1px solid var(--border); border-radius: 12px; padding: 20px 16px; text-align: center; transition: border-color 0.3s; }
.gp-payment-card:hover { border-color: rgba(201,165,90,0.2); }
.gp-payment-icon { font-size: 28px; margin-bottom: 8px; }
.gp-payment-name { font-family: var(--display); font-weight: 700; font-size: 16px; color: #fff; letter-spacing: 0.5px; }
.gp-payment-region { font-size: 11px; color: var(--gold); font-weight: 700; margin-top: 2px; letter-spacing: 0.5px; }
.gp-payment-desc { font-size: 11px; color: var(--text3); margin-top: 4px; }

/* SPONSORS */
.gp-sponsors { padding: 48px 24px; text-align: center; border-top: 1px solid var(--border); }
.gp-sponsor-label { font-family: var(--display); font-size: 12px; font-weight: 700; letter-spacing: 4px; color: var(--text3); margin-bottom: 24px; }
.gp-sponsor-row { display: flex; justify-content: center; gap: 24px; flex-wrap: wrap; margin-bottom: 16px; }
.gp-sponsor-item { font-size: 15px; color: var(--text3); font-weight: 600; padding: 10px 20px; border-radius: 8px; background: var(--card); border: 1px solid var(--border); }
.gp-sponsor-cta { font-size: 13px; color: var(--text3); }
.gp-sponsor-cta span { color: var(--gold); cursor: pointer; }

/* PREDICT PAGE */
.gp-page { max-width: 900px; margin: 0 auto; padding: 48px 24px 80px; }
.gp-page-title { font-family: var(--display); font-weight: 900; font-size: 42px; color: #fff; text-align: center; letter-spacing: 3px; }
.gp-page-sub { text-align: center; color: var(--text2); font-size: 15px; margin-bottom: 36px; }

/* WINNER SECTION */
.gp-winner-section { background: rgba(201,165,90,0.04); border: 1px solid rgba(201,165,90,0.12); border-radius: 20px; padding: 28px; margin-bottom: 28px; }
.gp-winner-label { font-family: var(--display); font-weight: 800; font-size: 22px; color: var(--gold); text-align: center; margin-bottom: 20px; letter-spacing: 2px; }
.gp-winner-scroll { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; }
.gp-winner-chip { display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 10px 12px; background: var(--card); border: 2px solid var(--border); border-radius: 12px; cursor: pointer; transition: all 0.2s; min-width: 70px; font-family: var(--body); color: var(--text2); font-size: 13px; }
.gp-winner-chip:hover { border-color: rgba(201,165,90,0.3); }
.gp-winner-chip.active { border-color: var(--gold); background: rgba(201,165,90,0.06); color: #fff; }
.gp-winner-chip-name { font-family: var(--display); font-weight: 700; font-size: 11px; letter-spacing: 0.5px; }

/* MATCH PREDICTIONS */
.gp-predict-subtitle { font-family: var(--display); font-weight: 800; font-size: 20px; color: #fff; letter-spacing: 2px; margin-bottom: 16px; }
.gp-predict-matches { margin-bottom: 28px; }
.gp-pred-match { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 20px; margin-bottom: 12px; }
.gp-pred-header { font-size: 12px; color: var(--text3); font-weight: 600; margin-bottom: 12px; text-align: center; letter-spacing: 0.5px; }
.gp-pred-row { display: flex; gap: 8px; justify-content: center; }
.gp-pred-pick { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 14px 8px; background: rgba(255,255,255,0.02); border: 2px solid var(--border); border-radius: 12px; cursor: pointer; font-family: var(--display); font-weight: 700; font-size: 14px; color: var(--text2); transition: all 0.2s; letter-spacing: 0.5px; }
.gp-pred-pick.draw { justify-content: center; max-width: 80px; font-size: 13px; }
.gp-pred-pick:hover { border-color: rgba(201,165,90,0.3); }
.gp-pred-pick.active { border-color: var(--gold); background: rgba(201,165,90,0.06); color: #fff; }

/* GROUPS */
.gp-group-section { margin-bottom: 28px; }
.gp-group-tabs { display: flex; flex-wrap: wrap; gap: 5px; justify-content: center; margin-bottom: 16px; }
.gp-group-tab { width: 38px; height: 38px; background: var(--card); border: 1px solid var(--border); border-radius: 8px; font-family: var(--display); font-weight: 700; font-size: 15px; color: var(--text3); cursor: pointer; transition: all 0.2s; letter-spacing: 0.5px; }
.gp-group-tab.active { background: rgba(201,165,90,0.1); border-color: var(--gold); color: var(--gold); }
.gp-group-card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 24px; }
.gp-group-name { font-family: var(--display); font-weight: 800; font-size: 20px; color: #fff; margin-bottom: 16px; letter-spacing: 1px; }
.gp-group-teams { display: flex; flex-direction: column; gap: 8px; }
.gp-team-btn { display: flex; align-items: center; gap: 14px; padding: 14px 18px; background: rgba(255,255,255,0.015); border: 2px solid transparent; border-radius: 12px; cursor: pointer; transition: all 0.2s; font-family: var(--body); color: var(--text2); }
.gp-team-btn:hover { background: rgba(255,255,255,0.03); }
.gp-team-btn.active { border-color: var(--gold); background: rgba(201,165,90,0.05); color: #fff; }
.gp-team-flag-big { font-size: 30px; }
.gp-team-name-big { font-family: var(--display); font-weight: 700; font-size: 18px; flex: 1; letter-spacing: 1px; }
.gp-check { color: var(--green); font-size: 22px; font-weight: 800; }

/* VIP PROMO */
.gp-vip-promo { background: rgba(201,165,90,0.04); border: 1px solid rgba(201,165,90,0.1); border-radius: 12px; padding: 14px 20px; text-align: center; font-size: 14px; color: var(--text2); margin-bottom: 24px; }

/* SUMMARY */
.gp-summary { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 28px; text-align: center; }
.gp-summary-title { font-family: var(--display); font-weight: 800; font-size: 20px; color: #fff; margin-bottom: 16px; letter-spacing: 1px; }
.gp-summary-chips { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-bottom: 20px; }
.gp-chip { background: rgba(60,172,59,0.08); border: 1px solid rgba(60,172,59,0.15); border-radius: 8px; padding: 6px 14px; font-size: 12px; color: var(--green); font-weight: 600; }
.gp-chip.gold { background: rgba(201,165,90,0.08); border-color: rgba(201,165,90,0.15); color: var(--gold); }

/* LEADERBOARD */
.gp-lb-podium { display: flex; justify-content: center; align-items: flex-end; gap: 16px; margin-bottom: 32px; }
.gp-podium-item { text-align: center; }
.gp-podium-flag { font-size: 28px; margin-bottom: 4px; }
.gp-podium-name { font-family: var(--display); font-weight: 700; font-size: 15px; color: #fff; letter-spacing: 0.5px; }
.gp-podium-pts { font-size: 13px; color: var(--gold); font-weight: 700; margin-bottom: 8px; }
.gp-podium-bar { display: flex; align-items: center; justify-content: center; font-size: 24px; border-radius: 8px 8px 0 0; }
.gp-podium-bar.b0 { width: 80px; height: 80px; background: linear-gradient(180deg, rgba(192,192,192,0.15), rgba(192,192,192,0.05)); border: 1px solid rgba(192,192,192,0.2); }
.gp-podium-bar.b1 { width: 80px; height: 110px; background: linear-gradient(180deg, rgba(201,165,90,0.2), rgba(201,165,90,0.05)); border: 1px solid rgba(201,165,90,0.3); }
.gp-podium-bar.b2 { width: 80px; height: 60px; background: linear-gradient(180deg, rgba(205,127,50,0.15), rgba(205,127,50,0.05)); border: 1px solid rgba(205,127,50,0.2); }
.gp-lb-table { background: var(--card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; margin-bottom: 28px; }
.gp-lb-header { display: flex; padding: 14px 20px; border-bottom: 1px solid var(--border); font-size: 11px; font-weight: 800; color: var(--text3); text-transform: uppercase; letter-spacing: 1px; }
.gp-lb-row { display: flex; padding: 14px 20px; border-bottom: 1px solid rgba(255,255,255,0.02); font-size: 14px; align-items: center; transition: background 0.2s; }
.gp-lb-row:hover { background: rgba(255,255,255,0.015); }
.gp-lb-row.highlight { background: rgba(201,165,90,0.02); }

/* REFERRAL */
.gp-referral { background: rgba(201,165,90,0.04); border: 1px solid rgba(201,165,90,0.12); border-radius: 16px; padding: 28px; text-align: center; }
.gp-referral h3 { font-family: var(--display); font-weight: 800; font-size: 22px; color: #fff; margin-bottom: 8px; letter-spacing: 1px; }
.gp-referral p { font-size: 14px; color: var(--text2); margin-bottom: 16px; }
.gp-referral-link { display: inline-flex; align-items: center; gap: 10px; background: rgba(0,0,0,0.3); border-radius: 10px; padding: 10px 16px; font-size: 13px; color: var(--gold); font-weight: 600; font-family: monospace; }

/* PRICING */
.gp-pricing-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; }
.gp-pricing-card { background: var(--card); border: 1px solid var(--border); border-radius: 20px; padding: 32px 24px; position: relative; transition: transform 0.3s; }
.gp-pricing-card.popular { border-color: var(--gold); transform: scale(1.02); background: rgba(201,165,90,0.03); }
.gp-popular-tag { position: absolute; top: -11px; left: 50%; transform: translateX(-50%); background: var(--gold); color: #000; font-family: var(--display); font-size: 11px; font-weight: 800; padding: 4px 16px; border-radius: 100px; letter-spacing: 2px; }
.gp-pricing-name { font-family: var(--display); font-weight: 800; font-size: 24px; letter-spacing: 1px; margin-bottom: 8px; }
.gp-pricing-price { font-family: var(--accent); font-size: 48px; color: #fff; }
.gp-pricing-period { font-size: 13px; color: var(--text3); margin-bottom: 20px; }
.gp-pricing-features { display: flex; flex-direction: column; gap: 10px; margin-bottom: 24px; }
.gp-pricing-feat { font-size: 13px; color: var(--text2); }

/* SECURITY */
.gp-security-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; margin-bottom: 28px; }
.gp-security-card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 24px; transition: border-color 0.3s; }
.gp-security-card:hover { border-color: rgba(201,165,90,0.15); }
.gp-security-icon { font-size: 32px; margin-bottom: 12px; }
.gp-security-title { font-family: var(--display); font-weight: 700; font-size: 18px; color: #fff; margin-bottom: 8px; letter-spacing: 0.5px; }
.gp-security-desc { font-size: 13px; line-height: 1.7; color: var(--text2); }
.gp-security-banner { background: linear-gradient(135deg, rgba(201,165,90,0.06), rgba(60,172,59,0.04)); border: 1px solid rgba(201,165,90,0.12); border-radius: 16px; padding: 28px; text-align: center; }
.gp-security-banner h3 { font-family: var(--display); font-weight: 800; font-size: 24px; color: #fff; margin-bottom: 10px; letter-spacing: 1px; }
.gp-security-banner p { font-size: 14px; line-height: 1.8; color: var(--text2); max-width: 700px; margin: 0 auto; }

/* MODAL */
.gp-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.75); backdrop-filter: blur(12px); display: flex; align-items: center; justify-content: center; z-index: 200; padding: 24px; }
.gp-modal { background: var(--bg3); border: 1px solid var(--border); border-radius: 20px; padding: 36px 32px; max-width: 420px; width: 100%; position: relative; }
.gp-modal-x { position: absolute; top: 14px; right: 14px; background: none; border: none; color: var(--text3); font-size: 16px; cursor: pointer; padding: 4px 8px; }
.gp-modal-trophy { font-size: 48px; text-align: center; margin-bottom: 8px; }
.gp-modal-title { font-family: var(--display); font-weight: 900; font-size: 30px; color: #fff; text-align: center; letter-spacing: 2px; }
.gp-modal-sub { text-align: center; color: var(--text2); font-size: 14px; margin-bottom: 24px; }
.gp-error-banner { background: rgba(231,76,76,0.1); border: 1px solid rgba(231,76,76,0.2); color: var(--red); border-radius: 10px; padding: 10px 14px; font-size: 13px; margin-bottom: 16px; text-align: center; font-weight: 600; }
.gp-form-group { margin-bottom: 14px; }
.gp-label { display: block; font-size: 12px; font-weight: 700; color: var(--text2); letter-spacing: 0.5px; margin-bottom: 6px; text-transform: uppercase; }
.gp-input { width: 100%; background: rgba(255,255,255,0.03); border: 1.5px solid var(--border); border-radius: 10px; padding: 12px 14px; font-size: 14px; color: #fff; font-family: var(--body); outline: none; transition: border-color 0.2s; }
.gp-input:focus { border-color: var(--gold); }
.gp-input.error { border-color: var(--red); }
.gp-field-error { font-size: 12px; color: var(--red); margin-top: 4px; display: block; }
.gp-pass-strength { height: 4px; background: rgba(255,255,255,0.05); border-radius: 2px; margin-top: 6px; overflow: hidden; }
.gp-pass-bar { height: 100%; border-radius: 2px; transition: all 0.3s; }
.gp-modal-security { display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 11px; color: var(--text3); margin-top: 14px; }
.gp-modal-toggle { text-align: center; font-size: 13px; color: var(--text3); margin-top: 16px; }
.gp-modal-toggle span { color: var(--gold); cursor: pointer; font-weight: 600; }

/* FOOTER */
.gp-footer { border-top: 1px solid var(--border); padding: 48px 24px 0; background: var(--bg2); }
.gp-footer-inner { max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: 1.2fr 2fr; gap: 48px; padding-bottom: 36px; }
.gp-footer-tagline { color: var(--text3); font-size: 13px; margin-top: 8px; }
.gp-footer-badges { display: flex; gap: 10px; margin-top: 12px; }
.gp-footer-badge { font-size: 11px; color: var(--text3); background: rgba(255,255,255,0.03); padding: 4px 10px; border-radius: 4px; border: 1px solid var(--border); }
.gp-footer-cols { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 24px; }
.gp-footer-cols h5 { font-family: var(--display); font-weight: 700; font-size: 14px; color: #fff; letter-spacing: 1px; margin-bottom: 14px; text-transform: uppercase; }
.gp-footer-link { font-size: 13px; color: var(--text3); margin-bottom: 8px; cursor: pointer; transition: color 0.2s; }
.gp-footer-link:hover { color: var(--gold); }
.gp-footer-bottom { border-top: 1px solid var(--border); padding: 16px 0; text-align: center; font-size: 12px; color: var(--text3); max-width: 1100px; margin: 0 auto; line-height: 1.7; }

/* ANIMATIONS */
@keyframes fadeUp { from { opacity:0; transform:translateY(16px) } to { opacity:1; transform:translateY(0) } }
`;
